import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { User, Achievement } from '../types';
import { getUserById, getUserAchievements, getBookmarkedIds, updateUserXP } from '../database/db';
import { useAuth } from './AuthContext';

interface UserContextType {
  user: User | null;
  isLoading: boolean;
  achievements: Achievement[];
  refreshUser: () => Promise<void>;
  addXP: (amount: number) => Promise<void>;
}

const UserContext = createContext<UserContextType>({} as UserContextType);

export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { userId, isAuthenticated } = useAuth();
  const [user, setUser] = useState<User | null>(null);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const refreshUser = useCallback(async () => {
    if (!userId) return;
    const [u, achs] = await Promise.all([
      getUserById(userId),
      getUserAchievements(userId),
    ]);
    setUser(u ?? null);
    setAchievements(achs);
    setIsLoading(false);
  }, [userId]);

  useEffect(() => {
    if (isAuthenticated && userId) {
      refreshUser();
    } else {
      setUser(null);
      setAchievements([]);
      setIsLoading(false);
    }
  }, [isAuthenticated, userId]);

  const addXP = useCallback(async (amount: number) => {
    if (!userId) return;
    await updateUserXP(userId, amount);
    await refreshUser();
  }, [userId, refreshUser]);

  return (
    <UserContext.Provider value={{ user, isLoading, achievements, refreshUser, addXP }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => useContext(UserContext);
