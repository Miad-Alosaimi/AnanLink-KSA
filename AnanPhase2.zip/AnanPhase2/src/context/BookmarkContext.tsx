import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { toggleBookmark, getBookmarkedIds } from '../database/db';
import { useAuth } from './AuthContext';

interface BookmarkContextType {
  bookmarkedIds: number[];
  toggleBookmarkItem: (opportunityId: number) => Promise<void>;
  isBookmarkedItem: (opportunityId: number) => boolean;
}

const BookmarkContext = createContext<BookmarkContextType>({} as BookmarkContextType);

export const BookmarkProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { userId, isAuthenticated } = useAuth();
  const [bookmarkedIds, setBookmarkedIds] = useState<number[]>([]);

  useEffect(() => {
    if (isAuthenticated && userId) {
      getBookmarkedIds(userId).then(setBookmarkedIds);
    } else {
      setBookmarkedIds([]);
    }
  }, [isAuthenticated, userId]);

  const toggleBookmarkItem = useCallback(async (opportunityId: number) => {
    if (!userId) return;
    const isNowBookmarked = await toggleBookmark(userId, opportunityId);
    setBookmarkedIds((prev) =>
      isNowBookmarked ? [...prev, opportunityId] : prev.filter((id) => id !== opportunityId)
    );
  }, [userId]);

  const isBookmarkedItem = useCallback((id: number) => bookmarkedIds.includes(id), [bookmarkedIds]);

  return (
    <BookmarkContext.Provider value={{ bookmarkedIds, toggleBookmarkItem, isBookmarkedItem }}>
      {children}
    </BookmarkContext.Provider>
  );
};

export const useBookmarks = () => useContext(BookmarkContext);
