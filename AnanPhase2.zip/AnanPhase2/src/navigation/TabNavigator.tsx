import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { Platform, View, StyleSheet } from 'react-native';

import { Colors, Typography, Strings } from '../constants';
import {
  TabParamList, HomeStackParamList, OpportunitiesStackParamList, ProfileStackParamList,
} from '../types';

import HomeScreen from '../screens/home/HomeScreen';
import HomeMapScreen from '../screens/home/HomeMapScreen';
import OpportunityListScreen from '../screens/opportunities/OpportunityListScreen';
import OpportunityDetailScreen from '../screens/opportunities/OpportunityDetailScreen';
import QRScannerScreen from '../screens/qr/QRScannerScreen';
import LeaderboardScreen from '../screens/leaderboard/LeaderboardScreen';
import UserProfileScreen from '../screens/profile/UserProfileScreen';
import BookmarksScreen from '../screens/profile/BookmarksScreen';

const Tab = createBottomTabNavigator<TabParamList>();
const HomeStack = createNativeStackNavigator<HomeStackParamList>();
const OppStack = createNativeStackNavigator<OpportunitiesStackParamList>();
const ProfileStack = createNativeStackNavigator<ProfileStackParamList>();

const HomeStackNav = () => (
  <HomeStack.Navigator screenOptions={{ headerShown: false }}>
    <HomeStack.Screen name="Home" component={HomeScreen} />
    <HomeStack.Screen name="HomeMap" component={HomeMapScreen} />
    <HomeStack.Screen name="OpportunityDetail" component={OpportunityDetailScreen} />
  </HomeStack.Navigator>
);

const OppStackNav = () => (
  <OppStack.Navigator screenOptions={{ headerShown: false }}>
    <OppStack.Screen name="OpportunityList" component={OpportunityListScreen} />
    <OppStack.Screen name="OpportunityDetail" component={OpportunityDetailScreen} />
  </OppStack.Navigator>
);

const ProfileStackNav = () => (
  <ProfileStack.Navigator screenOptions={{ headerShown: false }}>
    <ProfileStack.Screen name="UserProfile" component={UserProfileScreen} />
    <ProfileStack.Screen name="Bookmarks" component={BookmarksScreen} />
  </ProfileStack.Navigator>
);

const QRTabIcon = ({ focused }: { focused: boolean }) => (
  <View style={[styles.qrIconWrap, focused && styles.qrIconWrapActive]}>
    <Ionicons name="qr-code" size={22} color="#fff" />
  </View>
);

const TabNavigator: React.FC = () => (
  <Tab.Navigator
    screenOptions={({ route }) => ({
      headerShown: false,
      tabBarActiveTintColor: Colors.primary.purple,
      tabBarInactiveTintColor: Colors.text.muted,
      tabBarStyle: {
        backgroundColor: Colors.ui.tabBar,
        borderTopWidth: 1,
        borderTopColor: Colors.ui.border,
        height: Platform.OS === 'ios' ? 88 : 64,
        paddingBottom: Platform.OS === 'ios' ? 28 : 8,
        paddingTop: 4,
      },
      tabBarLabelStyle: { fontFamily: Typography.fontFamily.medium, fontSize: 11 },
      tabBarIcon: ({ focused, color, size }) => {
        let iconName: keyof typeof Ionicons.glyphMap = 'home';
        if (route.name === 'HomeTab') iconName = focused ? 'home' : 'home-outline';
        else if (route.name === 'OpportunitiesTab') iconName = focused ? 'grid' : 'grid-outline';
        else if (route.name === 'LeaderboardTab') iconName = focused ? 'trophy' : 'trophy-outline';
        else if (route.name === 'ProfileTab') iconName = focused ? 'person' : 'person-outline';
        if (route.name === 'QRTab') return <QRTabIcon focused={focused} />;
        return <Ionicons name={iconName} size={size} color={color} />;
      },
    })}
  >
    <Tab.Screen name="HomeTab" component={HomeStackNav} options={{ title: Strings.navigation.home }} />
    <Tab.Screen name="OpportunitiesTab" component={OppStackNav} options={{ title: Strings.navigation.opportunities }} />
    <Tab.Screen name="QRTab" component={QRScannerScreen} options={{ title: Strings.navigation.qrScanner, tabBarLabel: '' }} />
    <Tab.Screen name="LeaderboardTab" component={LeaderboardScreen} options={{ title: Strings.navigation.leaderboard }} />
    <Tab.Screen name="ProfileTab" component={ProfileStackNav} options={{ title: Strings.navigation.profile }} />
  </Tab.Navigator>
);

const styles = StyleSheet.create({
  qrIconWrap: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: Colors.primary.purple,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: Platform.OS === 'ios' ? 12 : 4,
    shadowColor: Colors.primary.purple, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 8, elevation: 6,
  },
  qrIconWrapActive: { backgroundColor: Colors.primary.teal },
});

export default TabNavigator;
