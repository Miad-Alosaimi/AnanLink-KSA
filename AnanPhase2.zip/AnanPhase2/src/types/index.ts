export type OpportunityType = 'hackathon' | 'internship' | 'opensource' | 'volunteer';

export interface Opportunity {
  id: number;
  title: string;
  type: OpportunityType;
  organization: string;
  description: string;
  deadline: string | null;
  location: string;
  latitude?: number | null;
  longitude?: number | null;
  xpReward: number;
  registrationLink: string;
  isActive: number;
  createdAt: string;
}

export interface User {
  id: number;
  fullName: string;
  firstName: string;
  lastName: string;
  email: string;
  university: string;
  major: string;
  specialty: string;
  academicYear: number;
  xp: number;
  level: number;
  createdAt: string;
}

export interface Achievement {
  id: number;
  userId: number;
  badgeIcon: string;
  title: string;
  description: string;
  earnedAt: string;
}

export interface RegisterData {
  firstName: string;
  lastName: string;
  email: string;
  university: string;
  major: string;
  specialty: string;
  academicYear: number;
  password: string;
  skills?: string[];
}

// Navigation
export type AuthStackParamList = {
  Login: undefined;
  RegisterStep1: undefined;
  RegisterStep2: { step1Data: Omit<RegisterData, 'password' | 'skills' | 'specialty'> };
  ForgotPassword: undefined;
};

export type RootStackParamList = {
  Onboarding: undefined;
  Auth: undefined;
  Main: undefined;
};

export type HomeStackParamList = {
  Home: undefined;
  HomeMap: undefined;
  OpportunityDetail: { opportunityId: number; type: OpportunityType };
};

export type OpportunitiesStackParamList = {
  OpportunityList: { type?: OpportunityType } | undefined;
  OpportunityDetail: { opportunityId: number; type: OpportunityType };
};

export type ProfileStackParamList = {
  UserProfile: undefined;
  Bookmarks: undefined;
};

export type TabParamList = {
  HomeTab: undefined;
  OpportunitiesTab: { type?: OpportunityType } | undefined;
  QRTab: undefined;
  LeaderboardTab: undefined;
  ProfileTab: undefined;
};
