import { SQLiteDatabase } from 'expo-sqlite';

const SEED_OPPORTUNITIES = [
  {
    title: 'هاكاثون KFUPM للابتكار 2025',
    type: 'hackathon',
    organization: 'جامعة الملك فهد للبترول والمعادن',
    description: 'هاكاثون يجمع طلاب الحوسبة لبناء حلول تقنية مبتكرة في مجال الطاقة والبيئة خلال 48 ساعة. الفرصة مفتوحة لجميع طلاب الجامعات السعودية.',
    deadline: '2025-06-15', location: 'الظهران، المنطقة الشرقية',
    latitude: 26.3083, longitude: 50.1324,
    xpReward: 150, registrationLink: 'https://hackathon.kfupm.edu.sa',
  },
  {
    title: 'تدريب صيفي — شركة أرامكو السعودية',
    type: 'internship',
    organization: 'أرامكو السعودية',
    description: 'برنامج تدريب صيفي في قسم تقنية المعلومات لمدة ثلاثة أشهر. فرصة للعمل مع فريق متميز على مشاريع تقنية حقيقية.',
    deadline: '2025-05-01', location: 'الرياض',
    latitude: 24.7136, longitude: 46.6753,
    xpReward: 200, registrationLink: 'https://careers.aramco.com/internships',
  },
  {
    title: 'مساهمة في مشروع Riyadh-OS',
    type: 'opensource',
    organization: 'مجتمع المطورين السعوديين',
    description: 'مشروع مفتوح المصدر يهدف إلى بناء نظام إدارة المهام بالعربية. نبحث عن مطورين للمساهمة في الكود وتحسين الواجهة.',
    deadline: null, location: 'عن بُعد',
    latitude: null, longitude: null,
    xpReward: 80, registrationLink: 'https://github.com/saudi-devs/riyadh-os',
  },
  {
    title: 'تطوع في مهرجان LEAP 2025',
    type: 'volunteer',
    organization: 'مؤتمر LEAP للتقنية',
    description: 'انضم كمتطوع في أكبر مؤتمر تقني في الشرق الأوسط. ستساعد في استقبال الضيوف وإدارة الجلسات.',
    deadline: '2025-02-10', location: 'الرياض',
    latitude: 24.8029, longitude: 46.6374,
    xpReward: 100, registrationLink: 'https://leap.tech/volunteer',
  },
  {
    title: 'هاكاثون الذكاء الاصطناعي — SDAIA',
    type: 'hackathon',
    organization: 'هيئة البيانات والذكاء الاصطناعي',
    description: 'هاكاثون وطني يركز على بناء تطبيقات الذكاء الاصطناعي التي تخدم رؤية 2030. جوائز تصل إلى 300,000 ريال.',
    deadline: '2025-07-20', location: 'الرياض',
    latitude: 24.6877, longitude: 46.7220,
    xpReward: 200, registrationLink: 'https://sdaia.gov.sa/hackathon',
  },
  {
    title: 'تدريب تعاوني — STC',
    type: 'internship',
    organization: 'شركة الاتصالات السعودية',
    description: 'فرصة تدريب تعاوني لمدة ستة أشهر في قسم التحول الرقمي. مناسب لطلاب السنة الثالثة والرابعة.',
    deadline: '2025-04-30', location: 'الرياض',
    latitude: 24.7500, longitude: 46.6700,
    xpReward: 180, registrationLink: 'https://www.stc.com.sa/careers',
  },
  {
    title: 'مساهمة في مكتبة Arabic-NLP',
    type: 'opensource',
    organization: 'مختبر ARABERT',
    description: 'مكتبة معالجة اللغة العربية الطبيعية مفتوحة المصدر. نبحث عن مساهمين لتطوير نماذج التصنيف والتلخيص.',
    deadline: null, location: 'عن بُعد',
    latitude: null, longitude: null,
    xpReward: 90, registrationLink: 'https://github.com/CAMeL-Lab/camel_tools',
  },
  {
    title: 'تطوع في يوم التقنية الوطني',
    type: 'volunteer',
    organization: 'وزارة الاتصالات وتقنية المعلومات',
    description: 'مبادرة وطنية لتعليم الأطفال أساسيات البرمجة وتقنية المعلومات. نحتاج متطوعين من طلاب الحوسبة.',
    deadline: '2025-09-05', location: 'جدة',
    latitude: 21.5433, longitude: 39.1728,
    xpReward: 70, registrationLink: 'https://mcit.gov.sa/volunteer',
  },
];

const LEADERBOARD_USERS = [
  { fullName: 'محمد العتيبي', firstName: 'محمد', lastName: 'العتيبي', email: 'leaderboard1@test.com', university: 'KFUPM', major: 'علوم الحاسب', specialty: 'AI', academicYear: 3, xp: 850, level: 9, password: 'test' },
  { fullName: 'سارة الزهراني', firstName: 'سارة', lastName: 'الزهراني', email: 'leaderboard2@test.com', university: 'KAU', major: 'هندسة الحاسب', specialty: 'Backend', academicYear: 4, xp: 720, level: 8, password: 'test' },
  { fullName: 'أحمد الغامدي', firstName: 'أحمد', lastName: 'الغامدي', email: 'leaderboard3@test.com', university: 'KSU', major: 'تقنية المعلومات', specialty: 'Mobile', academicYear: 2, xp: 610, level: 7, password: 'test' },
  { fullName: 'نورة السبيعي', firstName: 'نورة', lastName: 'السبيعي', email: 'leaderboard4@test.com', university: 'KFUPM', major: 'علوم الحاسب', specialty: 'Frontend', academicYear: 3, xp: 540, level: 6, password: 'test' },
  { fullName: 'عبدالرحمن الدوسري', firstName: 'عبدالرحمن', lastName: 'الدوسري', email: 'leaderboard5@test.com', university: 'IAU', major: 'نظم المعلومات', specialty: 'Cloud', academicYear: 4, xp: 430, level: 5, password: 'test' },
];

export const seedDatabase = async (db: SQLiteDatabase): Promise<void> => {
  const { count: oppCount } = (await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) as count FROM opportunities')) ?? { count: 0 };
  if (oppCount === 0) {
    for (const opp of SEED_OPPORTUNITIES) {
      await db.runAsync(
        `INSERT INTO opportunities (title, type, organization, description, deadline, location, latitude, longitude, xpReward, registrationLink)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [opp.title, opp.type, opp.organization, opp.description, opp.deadline ?? null, opp.location, opp.latitude ?? null, opp.longitude ?? null, opp.xpReward, opp.registrationLink]
      );
    }
  }

  const { count: userCount } = (await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) as count FROM users')) ?? { count: 0 };
  if (userCount === 0) {
    for (const u of LEADERBOARD_USERS) {
      await db.runAsync(
        `INSERT INTO users (fullName, firstName, lastName, email, university, major, specialty, academicYear, xp, level, password)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [u.fullName, u.firstName, u.lastName, u.email, u.university, u.major, u.specialty, u.academicYear, u.xp, u.level, u.password]
      );
    }
  }
};
