import * as SQLite from 'expo-sqlite';
import { ALL_TABLES } from './schema';
import { seedDatabase } from './seeds';

let _db: SQLite.SQLiteDatabase | null = null;

export const getDatabase = (): SQLite.SQLiteDatabase => {
  if (!_db) _db = SQLite.openDatabaseSync('ananphase2.db');
  return _db;
};

export const initializeDatabase = async (): Promise<void> => {
  const db = getDatabase();
  await db.execAsync('PRAGMA journal_mode = WAL;');
  for (const sql of ALL_TABLES) {
    await db.execAsync(sql);
  }
  await seedDatabase(db);
};

// --- User queries ---
export const createUser = async (data: {
  firstName: string; lastName: string; email: string;
  university: string; major: string; specialty: string;
  academicYear: number; password: string;
}): Promise<number> => {
  const db = getDatabase();
  const fullName = `${data.firstName} ${data.lastName}`;
  const result = await db.runAsync(
    `INSERT INTO users (fullName, firstName, lastName, email, university, major, specialty, academicYear, xp, level, password)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 1, ?)`,
    [fullName, data.firstName, data.lastName, data.email, data.university, data.major, data.specialty, data.academicYear, data.password]
  );
  return result.lastInsertRowId;
};

export const addUserSkills = async (userId: number, skills: string[]): Promise<void> => {
  const db = getDatabase();
  for (const skill of skills) {
    await db.runAsync(
      'INSERT INTO user_skills (userId, skillName) VALUES (?, ?)',
      [userId, skill]
    );
  }
};

export const getUserById = async (id: number) =>
  getDatabase().getFirstAsync<any>('SELECT * FROM users WHERE id = ?', [id]);

export const getUserByEmail = async (email: string) =>
  getDatabase().getFirstAsync<any>('SELECT * FROM users WHERE email = ?', [email]);

export const verifyUserCredentials = async (email: string, password: string) =>
  getDatabase().getFirstAsync<any>(
    'SELECT * FROM users WHERE email = ? AND password = ?',
    [email, password]
  );

export const updateUserXP = async (userId: number, xpToAdd: number): Promise<void> => {
  const db = getDatabase();
  const user = await getUserById(userId);
  if (!user) return;
  const newXp = user.xp + xpToAdd;
  const newLevel = Math.floor(newXp / 100) + 1;
  await db.runAsync('UPDATE users SET xp = ?, level = ? WHERE id = ?', [newXp, newLevel, userId]);
};

export const addAchievement = async (userId: number, badgeIcon: string, title: string, description: string): Promise<void> => {
  await getDatabase().runAsync(
    'INSERT INTO achievements (userId, badgeIcon, title, description) VALUES (?, ?, ?, ?)',
    [userId, badgeIcon, title, description]
  );
};

export const getUserAchievements = async (userId: number) =>
  getDatabase().getAllAsync<any>('SELECT * FROM achievements WHERE userId = ? ORDER BY earnedAt DESC', [userId]);

export const getLeaderboard = async (limit = 20) =>
  getDatabase().getAllAsync<any>('SELECT id, fullName, firstName, university, xp, level FROM users ORDER BY xp DESC LIMIT ?', [limit]);

// --- Opportunity queries ---
export const getAllOpportunities = async () =>
  getDatabase().getAllAsync<any>('SELECT * FROM opportunities WHERE isActive = 1 ORDER BY createdAt DESC');

export const getOpportunitiesByType = async (type: string) =>
  getDatabase().getAllAsync<any>('SELECT * FROM opportunities WHERE isActive = 1 AND type = ? ORDER BY createdAt DESC', [type]);

export const getOpportunityById = async (id: number) =>
  getDatabase().getFirstAsync<any>('SELECT * FROM opportunities WHERE id = ?', [id]);

export const getRecentOpportunities = async (limit = 6) =>
  getDatabase().getAllAsync<any>('SELECT * FROM opportunities WHERE isActive = 1 ORDER BY createdAt DESC LIMIT ?', [limit]);

export const getOpportunitiesWithLocation = async () =>
  getDatabase().getAllAsync<any>('SELECT * FROM opportunities WHERE isActive = 1 AND latitude IS NOT NULL');

export const getOpportunityCountByType = async (): Promise<Record<string, number>> => {
  const rows = await getDatabase().getAllAsync<{ type: string; count: number }>(
    "SELECT type, COUNT(*) as count FROM opportunities WHERE isActive = 1 GROUP BY type"
  );
  const map: Record<string, number> = { hackathon: 0, internship: 0, opensource: 0, volunteer: 0 };
  for (const row of rows) map[row.type] = row.count;
  return map;
};

// --- Bookmark queries ---
export const toggleBookmark = async (userId: number, opportunityId: number): Promise<boolean> => {
  const db = getDatabase();
  const existing = await db.getFirstAsync<any>(
    'SELECT id FROM bookmarks WHERE userId = ? AND opportunityId = ?',
    [userId, opportunityId]
  );
  if (existing) {
    await db.runAsync('DELETE FROM bookmarks WHERE userId = ? AND opportunityId = ?', [userId, opportunityId]);
    return false;
  } else {
    await db.runAsync('INSERT INTO bookmarks (userId, opportunityId) VALUES (?, ?)', [userId, opportunityId]);
    return true;
  }
};

export const getBookmarkedOpportunities = async (userId: number) =>
  getDatabase().getAllAsync<any>(
    `SELECT o.* FROM opportunities o
     INNER JOIN bookmarks b ON o.id = b.opportunityId
     WHERE b.userId = ? ORDER BY b.createdAt DESC`,
    [userId]
  );

export const getBookmarkedIds = async (userId: number): Promise<number[]> => {
  const rows = await getDatabase().getAllAsync<{ opportunityId: number }>(
    'SELECT opportunityId FROM bookmarks WHERE userId = ?', [userId]
  );
  return rows.map((r) => r.opportunityId);
};

// --- QR scan logs ---
export const saveScanLog = async (params: {
  userId: number; eventId: string; eventTitle: string;
  eventType: string; xpEarned: number; rawQrData: string;
}): Promise<void> => {
  await getDatabase().runAsync(
    `INSERT INTO scan_logs (user_uid, event_id, event_title, event_type, xp_earned, raw_qr_data)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [params.userId, params.eventId, params.eventTitle, params.eventType, params.xpEarned, params.rawQrData]
  );
};

// --- Cache ---
export const getCachedEvents = async (source: string) => {
  const row = await getDatabase().getFirstAsync<{ event_data: string; cached_at: string }>(
    'SELECT event_data, cached_at FROM cached_events WHERE source = ?', [source]
  );
  return row ?? null;
};

export const upsertCachedEvents = async (source: string, data: any[]): Promise<void> => {
  await getDatabase().runAsync(
    `INSERT INTO cached_events (source, event_data, cached_at) VALUES (?, ?, CURRENT_TIMESTAMP)
     ON CONFLICT(source) DO UPDATE SET event_data = excluded.event_data, cached_at = CURRENT_TIMESTAMP`,
    [source, JSON.stringify(data)]
  );
};
