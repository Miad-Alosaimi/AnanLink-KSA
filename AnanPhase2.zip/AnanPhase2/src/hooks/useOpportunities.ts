import { useState, useEffect, useCallback } from 'react';
import { Opportunity } from '../types';
import { getAllOpportunities, getCachedEvents, upsertCachedEvents } from '../database/db';
import { fetchGithubOpportunities } from '../services/githubService';

const CACHE_TTL_MINUTES = 30;

const isCacheFresh = (cachedAt: string): boolean => {
  const diff = (Date.now() - new Date(cachedAt).getTime()) / 60000;
  return diff < CACHE_TTL_MINUTES;
};

export const useOpportunities = () => {
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const loadOpportunities = useCallback(async (forceRefresh = false) => {
    const local = await getAllOpportunities();

    // Check cache for GitHub data
    const cached = await getCachedEvents('github');
    if (!forceRefresh && cached && isCacheFresh(cached.cached_at)) {
      const parsed: Opportunity[] = JSON.parse(cached.event_data);
      setOpportunities([...local, ...parsed]);
      setIsLoading(false);
      setIsRefreshing(false);
      return;
    }

    // Fetch fresh from GitHub
    try {
      const githubData = await fetchGithubOpportunities();
      await upsertCachedEvents('github', githubData);
      setOpportunities([...local, ...(githubData as Opportunity[])]);
    } catch {
      const stale = cached ? (JSON.parse(cached.event_data) as Opportunity[]) : [];
      setOpportunities([...local, ...stale]);
    }

    setIsLoading(false);
    setIsRefreshing(false);
  }, []);

  useEffect(() => { loadOpportunities(); }, []);

  const refresh = () => {
    setIsRefreshing(true);
    loadOpportunities(true);
  };

  return { opportunities, isLoading, isRefreshing, refresh };
};
