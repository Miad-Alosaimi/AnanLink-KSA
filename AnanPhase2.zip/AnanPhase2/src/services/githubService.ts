import { Opportunity } from '../types';

const GITHUB_API = 'https://api.github.com/search/repositories';

export const fetchGithubOpportunities = async (): Promise<Partial<Opportunity>[]> => {
  try {
    const url = `${GITHUB_API}?q=good-first-issues:>3+language:javascript+language:python&sort=stars&per_page=8`;
    const response = await fetch(url, {
      headers: { Accept: 'application/vnd.github.v3+json' },
    });
    if (!response.ok) throw new Error('GitHub API error');
    const data = await response.json();

    return (data.items ?? []).map((repo: any) => ({
      title: repo.full_name,
      type: 'opensource' as const,
      organization: repo.owner?.login ?? 'Unknown',
      description: repo.description ?? 'مشروع مفتوح المصدر على GitHub',
      deadline: null,
      location: 'عن بُعد',
      xpReward: 80,
      registrationLink: repo.html_url,
      isActive: 1,
    }));
  } catch {
    return [];
  }
};
