import React from 'react';
import { TouchableOpacity, Text, ActivityIndicator, StyleSheet, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Typography } from '../../constants';

interface ButtonProps {
  title: string;
  onPress: () => void;
  isLoading?: boolean;
  disabled?: boolean;
  variant?: 'primary' | 'outline' | 'gradient';
  style?: ViewStyle;
}

const Button: React.FC<ButtonProps> = ({ title, onPress, isLoading, disabled, variant = 'primary', style }) => {
  const isDisabled = disabled || isLoading;

  if (variant === 'gradient') {
    return (
      <TouchableOpacity onPress={onPress} disabled={isDisabled} activeOpacity={0.85} style={[styles.base, isDisabled && styles.disabled, style]}>
        <LinearGradient colors={[Colors.gradient.start, Colors.gradient.end]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.gradientInner}>
          {isLoading ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.text}>{title}</Text>}
        </LinearGradient>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      style={[styles.base, variant === 'primary' ? styles.primary : styles.outline, isDisabled && styles.disabled, style]}
      onPress={onPress} disabled={isDisabled} activeOpacity={0.85}
    >
      {isLoading
        ? <ActivityIndicator color={variant === 'primary' ? '#fff' : Colors.primary.purple} size="small" />
        : <Text style={[styles.text, variant === 'outline' && styles.textOutline]}>{title}</Text>}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  base: { borderRadius: 14, overflow: 'hidden' },
  primary: { backgroundColor: Colors.primary.purple, paddingVertical: 15, alignItems: 'center' },
  outline: { borderWidth: 1.5, borderColor: Colors.primary.purple, paddingVertical: 15, alignItems: 'center' },
  gradientInner: { paddingVertical: 15, alignItems: 'center' },
  disabled: { opacity: 0.6 },
  text: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.base, color: '#fff' },
  textOutline: { color: Colors.primary.purple },
});

export default Button;
