import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { Colors, Typography } from '../../constants';

interface FilterChipProps {
  label: string;
  active: boolean;
  onPress: () => void;
  color?: string;
}

const FilterChip: React.FC<FilterChipProps> = ({ label, active, onPress, color = Colors.primary.purple }) => (
  <TouchableOpacity
    style={[styles.chip, active ? { backgroundColor: color, borderColor: color } : styles.chipInactive]}
    onPress={onPress}
    activeOpacity={0.8}
  >
    <Text style={[styles.label, active ? styles.labelActive : styles.labelInactive]}>{label}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  chip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5, marginRight: 8 },
  chipInactive: { backgroundColor: Colors.background.card, borderColor: Colors.ui.border },
  label: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm },
  labelActive: { color: '#fff' },
  labelInactive: { color: Colors.text.secondary },
});

export default FilterChip;
