import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { Opportunity } from '../../types';
import { getBookmarkedOpportunities } from '../../database/db';
import { useAuth, useBookmarks } from '../../context';

const TYPE_COLORS: Record<string, string> = {
  hackathon: Colors.opportunity.hackathon,
  internship: Colors.opportunity.internship,
  opensource: Colors.opportunity.opensource,
  volunteer: Colors.opportunity.volunteer,
};

const BookmarksScreen: React.FC = () => {
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const { userId } = useAuth();
  const { toggleBookmarkItem } = useBookmarks();
  const [bookmarks, setBookmarks] = useState<Opportunity[]>([]);
  const [search, setSearch] = useState('');

  const loadBookmarks = useCallback(async () => {
    if (!userId) return;
    const data = await getBookmarkedOpportunities(userId);
    setBookmarks(data);
  }, [userId]);

  useFocusEffect(useCallback(() => { loadBookmarks(); }, [loadBookmarks]));

  const filtered = search.trim()
    ? bookmarks.filter((b) => b.title.toLowerCase().includes(search.toLowerCase()) || b.organization.toLowerCase().includes(search.toLowerCase()))
    : bookmarks;

  const handleRemove = async (id: number) => {
    await toggleBookmarkItem(id);
    setBookmarks((prev) => prev.filter((b) => b.id !== id));
  };

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <View style={[styles.header, { paddingTop: insets.top + 16 }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={22} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{Strings.bookmarks.title}</Text>
        <View style={{ width: 36 }} />
      </View>

      {/* Search */}
      <View style={styles.searchWrap}>
        <Ionicons name="search" size={18} color={Colors.text.secondary} />
        <TextInput
          style={styles.searchInput}
          placeholder="ابحث في المحفوظات..."
          placeholderTextColor={Colors.ui.placeholder}
          value={search}
          onChangeText={setSearch}
          textAlign="right"
        />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="bookmark-outline" size={52} color={Colors.ui.disabled} />
            <Text style={styles.emptyTitle}>{Strings.bookmarks.empty}</Text>
            <Text style={styles.emptyMsg}>{Strings.bookmarks.emptyMessage}</Text>
          </View>
        }
        renderItem={({ item }) => {
          const color = TYPE_COLORS[item.type];
          return (
            <View style={styles.card}>
              <View style={styles.cardTop}>
                <TouchableOpacity onPress={() => handleRemove(item.id)}>
                  <Ionicons name="bookmark" size={20} color={Colors.primary.purple} />
                </TouchableOpacity>
                <View style={[styles.typeTag, { backgroundColor: color + '20' }]}>
                  <Text style={[styles.typeText, { color }]}>{item.type}</Text>
                </View>
              </View>
              <Text style={styles.title}>{item.title}</Text>
              <Text style={styles.org}>{item.organization}</Text>
              <View style={styles.cardFooter}>
                <View style={styles.locationRow}>
                  <Ionicons name="location-outline" size={12} color={Colors.text.secondary} />
                  <Text style={styles.locationText}>{item.location}</Text>
                </View>
                {item.deadline ? <Text style={styles.deadline}>{item.deadline}</Text> : null}
              </View>
            </View>
          );
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background.app },
  header: { backgroundColor: Colors.primary.purple, paddingHorizontal: 16, paddingBottom: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  backBtn: { padding: 4 },
  headerTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.xl, color: '#fff' },
  searchWrap: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: Colors.background.card, marginHorizontal: 16, marginTop: 14, marginBottom: 8, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10, borderWidth: 1, borderColor: Colors.ui.border },
  searchInput: { flex: 1, fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.primary },
  list: { padding: 16, paddingBottom: 40 },
  card: { backgroundColor: Colors.background.card, borderRadius: 16, padding: 16, marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  typeTag: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  typeText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.xs },
  title: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.base, color: Colors.text.primary, textAlign: 'right', marginBottom: 4 },
  org: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm, color: Colors.primary.purple, textAlign: 'right', marginBottom: 10 },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  locationRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  locationText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary },
  deadline: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary },
  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyTitle: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.lg, color: Colors.text.primary },
  emptyMsg: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.secondary, textAlign: 'center' },
});

export default BookmarksScreen;
