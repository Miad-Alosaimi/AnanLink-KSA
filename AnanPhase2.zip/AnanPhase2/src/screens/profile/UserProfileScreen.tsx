import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { ProfileStackParamList } from '../../types';
import { useAuth, useUser } from '../../context';

type Nav = NativeStackNavigationProp<ProfileStackParamList>;

const MENU_ITEMS = [
  { icon: 'bookmark-outline', label: Strings.profile.bookmarks, screen: 'Bookmarks' },
  { icon: 'create-outline', label: Strings.profile.editProfile, screen: null },
  { icon: 'notifications-outline', label: Strings.profile.notifications, screen: null },
  { icon: 'information-circle-outline', label: Strings.profile.about, screen: null },
];

const UserProfileScreen: React.FC = () => {
  const navigation = useNavigation<Nav>();
  const insets = useSafeAreaInsets();
  const { logout } = useAuth();
  const { user, achievements } = useUser();

  const handleLogout = () => {
    Alert.alert('', Strings.profile.logoutConfirm, [
      { text: Strings.profile.logoutNo, style: 'cancel' },
      { text: Strings.profile.logoutYes, style: 'destructive', onPress: logout },
    ]);
  };

  if (!user) return null;

  const initials = `${user.firstName?.[0] ?? ''}${user.lastName?.[0] ?? ''}`.toUpperCase();
  const levelProgress = (user.xp % 100) / 100;
  const xpToNext = (user.level * 100) - user.xp;

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <LinearGradient
          colors={[Colors.gradient.start, Colors.gradient.end]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={[styles.header, { paddingTop: insets.top + 20 }]}
        >
          <View style={styles.decorCircle} />
          <Text style={styles.headerTitle}>{Strings.profile.title}</Text>
          <View style={styles.avatarSection}>
            <View style={styles.avatarCircle}>
              <Text style={styles.avatarText}>{initials}</Text>
            </View>
            <View style={styles.levelBadge}>
              <Text style={styles.levelText}>⭐ المستوى {user.level}</Text>
            </View>
          </View>
          <Text style={styles.userName}>{user.fullName}</Text>
          <Text style={styles.userEmail}>{user.email}</Text>
          <Text style={styles.userUni}>{user.university}</Text>

          {/* XP Bar */}
          <View style={styles.xpBarCard}>
            <View style={styles.xpBarRow}>
              <Text style={styles.xpBarText}>{xpToNext > 0 ? `${xpToNext} XP للمستوى التالي` : 'وصلت للمستوى الأعلى!'}</Text>
              <Text style={styles.xpBarLabel}>{user.xp} XP</Text>
            </View>
            <View style={styles.xpTrack}>
              <LinearGradient
                colors={[Colors.gradient.start, Colors.gradient.end]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                style={[styles.xpFill, { width: `${Math.min(levelProgress * 100, 100)}%` }]}
              />
            </View>
          </View>
        </LinearGradient>

        <View style={styles.content}>
          {/* Achievements */}
          {achievements.length > 0 && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>{Strings.profile.achievements}</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.achieveRow}>
                {achievements.map((ach) => (
                  <View key={ach.id} style={styles.achieveBadge}>
                    <View style={styles.achieveIcon}>
                      <Ionicons name={ach.badgeIcon as any} size={22} color={Colors.primary.purple} />
                    </View>
                    <Text style={styles.achieveTitle} numberOfLines={1}>{ach.title}</Text>
                  </View>
                ))}
              </ScrollView>
            </View>
          )}

          {/* Menu */}
          <View style={styles.menuCard}>
            {MENU_ITEMS.map((item, idx) => (
              <TouchableOpacity
                key={item.label}
                style={[styles.menuItem, idx < MENU_ITEMS.length - 1 && styles.menuItemBorder]}
                onPress={() => item.screen ? navigation.navigate(item.screen as any) : null}
                activeOpacity={0.75}
              >
                <Ionicons name="chevron-back" size={16} color={Colors.text.muted} />
                <Text style={styles.menuLabel}>{item.label}</Text>
                <View style={styles.menuIcon}>
                  <Ionicons name={item.icon as any} size={20} color={Colors.primary.purple} />
                </View>
              </TouchableOpacity>
            ))}
          </View>

          {/* Logout */}
          <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout} activeOpacity={0.8}>
            <Text style={styles.logoutText}>{Strings.profile.logout}</Text>
            <Ionicons name="log-out-outline" size={20} color={Colors.status.error} />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background.app },
  header: { paddingHorizontal: 20, paddingBottom: 32, overflow: 'hidden', alignItems: 'center' },
  decorCircle: { position: 'absolute', width: 250, height: 250, borderRadius: 125, backgroundColor: 'rgba(255,255,255,0.06)', top: -60, right: -60 },
  headerTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.xl, color: '#fff', alignSelf: 'flex-end', marginBottom: 16 },
  avatarSection: { alignItems: 'center', marginBottom: 10 },
  avatarCircle: { width: 84, height: 84, borderRadius: 42, backgroundColor: 'rgba(255,255,255,0.25)', alignItems: 'center', justifyContent: 'center', borderWidth: 2.5, borderColor: 'rgba(255,255,255,0.5)', marginBottom: 8 },
  avatarText: { fontFamily: Typography.fontFamily.bold, fontSize: 28, color: '#fff' },
  levelBadge: { backgroundColor: 'rgba(255,255,255,0.25)', paddingHorizontal: 14, paddingVertical: 5, borderRadius: 20 },
  levelText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm, color: '#fff' },
  userName: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.xl, color: '#fff', marginBottom: 4 },
  userEmail: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.sm, color: 'rgba(255,255,255,0.8)', marginBottom: 2 },
  userUni: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.sm, color: 'rgba(255,255,255,0.7)', marginBottom: 20 },
  xpBarCard: { width: '100%', backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: 14, padding: 14 },
  xpBarRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  xpBarLabel: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.sm, color: '#fff' },
  xpBarText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: 'rgba(255,255,255,0.8)' },
  xpTrack: { height: 8, backgroundColor: 'rgba(255,255,255,0.3)', borderRadius: 4, overflow: 'hidden' },
  xpFill: { height: '100%', borderRadius: 4 },
  content: { paddingHorizontal: 20, paddingTop: 20, paddingBottom: 40 },
  section: { marginBottom: 20 },
  sectionTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.lg, color: Colors.text.primary, textAlign: 'right', marginBottom: 12 },
  achieveRow: { gap: 12, paddingBottom: 4 },
  achieveBadge: { alignItems: 'center', width: 80, gap: 6 },
  achieveIcon: { width: 52, height: 52, borderRadius: 26, backgroundColor: Colors.opportunity.hackathonLight, alignItems: 'center', justifyContent: 'center' },
  achieveTitle: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary, textAlign: 'center' },
  menuCard: { backgroundColor: Colors.background.card, borderRadius: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  menuItem: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 16, gap: 12 },
  menuItemBorder: { borderBottomWidth: 1, borderBottomColor: Colors.ui.divider },
  menuIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: Colors.opportunity.hackathonLight, alignItems: 'center', justifyContent: 'center' },
  menuLabel: { flex: 1, fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.base, color: Colors.text.primary, textAlign: 'right' },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 10, backgroundColor: Colors.background.card, borderRadius: 14, padding: 18, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  logoutText: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.base, color: Colors.status.error },
});

export default UserProfileScreen;
