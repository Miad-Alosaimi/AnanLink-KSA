import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { AuthStackParamList } from '../../types';
import { Button, Input } from '../../components/common';
import { useAuth } from '../../context';

type Nav = NativeStackNavigationProp<AuthStackParamList>;

const LoginScreen: React.FC = () => {
  const navigation = useNavigation<Nav>();
  const insets = useSafeAreaInsets();
  const { login } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string; general?: string }>({});

  const validate = () => {
    const e: typeof errors = {};
    if (!email.trim()) e.email = Strings.auth.errors.emailRequired;
    else if (!/\S+@\S+\.\S+/.test(email)) e.email = Strings.auth.errors.emailInvalid;
    if (!password.trim()) e.password = Strings.auth.errors.passwordRequired;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleLogin = async () => {
    if (!validate()) return;
    setIsLoading(true);
    setErrors({});
    const result = await login(email, password);
    setIsLoading(false);
    if (!result.success) setErrors({ general: result.error });
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <LinearGradient
          colors={[Colors.gradient.start, Colors.gradient.end]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={[styles.header, { paddingTop: insets.top + 20 }]}
        >
          <View style={styles.decorCircle} />
          <View style={styles.logoBox}>
            <Text style={styles.logoEmoji}>✦</Text>
          </View>
          <Text style={styles.appName}>{Strings.app.name}</Text>
        </LinearGradient>

        <View style={styles.card}>
          <Text style={styles.title}>{Strings.auth.login.title}</Text>
          <Text style={styles.subtitle}>{Strings.auth.login.subtitle}</Text>

          {errors.general ? (
            <View style={styles.errorBanner}>
              <Ionicons name="alert-circle-outline" size={16} color={Colors.status.error} />
              <Text style={styles.errorText}>{errors.general}</Text>
            </View>
          ) : null}

          <Input label={Strings.auth.login.emailLabel} value={email} onChangeText={setEmail}
            placeholder={Strings.auth.login.emailPlaceholder} keyboardType="email-address"
            autoCapitalize="none" leftIcon="mail-outline" error={errors.email} />

          <Input label={Strings.auth.login.passwordLabel} value={password} onChangeText={setPassword}
            placeholder={Strings.auth.login.passwordPlaceholder} secureTextEntry
            leftIcon="lock-closed-outline" error={errors.password} />

          <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')} style={styles.forgotLink}>
            <Text style={styles.forgotText}>{Strings.auth.login.forgotPassword}</Text>
          </TouchableOpacity>

          <Button title={Strings.auth.login.loginButton} onPress={handleLogin} isLoading={isLoading} variant="gradient" style={styles.btn} />

          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>{Strings.auth.login.orDivider}</Text>
            <View style={styles.dividerLine} />
          </View>

          <View style={styles.socialRow}>
            {[{ label: 'GitHub', icon: 'logo-github' }, { label: 'Apple', icon: 'logo-apple' }, { label: 'Google', icon: 'logo-google' }].map((s) => (
              <TouchableOpacity key={s.label} style={styles.socialBtn} activeOpacity={0.8}>
                <Ionicons name={s.icon as any} size={18} color={Colors.text.primary} />
                <Text style={styles.socialText}>{s.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.registerRow}>
            <Text style={styles.registerText}>{Strings.auth.login.noAccount}</Text>
            <TouchableOpacity onPress={() => navigation.navigate('RegisterStep1')}>
              <Text style={styles.registerLink}>{Strings.auth.login.signUp}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background.app },
  scroll: { flexGrow: 1 },
  header: { minHeight: 230, alignItems: 'center', justifyContent: 'center', paddingBottom: 44, overflow: 'hidden' },
  decorCircle: { position: 'absolute', width: 250, height: 250, borderRadius: 125, backgroundColor: 'rgba(255,255,255,0.07)', top: -60, right: -60 },
  logoBox: { width: 72, height: 72, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.4)', marginBottom: 12 },
  logoEmoji: { fontSize: 32, color: '#fff' },
  appName: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize['2xl'], color: '#fff' },
  card: { flex: 1, backgroundColor: Colors.background.card, borderTopLeftRadius: 30, borderTopRightRadius: 30, marginTop: -24, paddingHorizontal: 24, paddingTop: 32, paddingBottom: 40 },
  title: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize['2xl'], color: Colors.text.primary, textAlign: 'right', marginBottom: 6 },
  subtitle: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.secondary, textAlign: 'right', marginBottom: 24 },
  errorBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#FEF2F2', borderRadius: 10, padding: 12, marginBottom: 16, borderWidth: 1, borderColor: '#FCA5A5' },
  errorText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.sm, color: Colors.status.error, flex: 1, textAlign: 'right' },
  forgotLink: { alignSelf: 'flex-end', marginBottom: 20, marginTop: -8 },
  forgotText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm, color: Colors.primary.purple },
  btn: { marginBottom: 24 },
  divider: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 16 },
  dividerLine: { flex: 1, height: 1, backgroundColor: Colors.ui.border },
  dividerText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.sm, color: Colors.text.secondary },
  socialRow: { flexDirection: 'row', gap: 10, marginBottom: 28 },
  socialBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, borderWidth: 1.5, borderColor: Colors.ui.border, borderRadius: 12, paddingVertical: 11 },
  socialText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm, color: Colors.text.primary },
  registerRow: { flexDirection: 'row', justifyContent: 'center', gap: 6 },
  registerText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.secondary },
  registerLink: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.base, color: Colors.primary.purple },
});

export default LoginScreen;
