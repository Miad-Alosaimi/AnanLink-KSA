import React, { useState, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, FlatList, Dimensions, ViewToken,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { RootStackParamList } from '../../types';
import { ONBOARDING_KEY } from '../../context';

type Nav = NativeStackNavigationProp<RootStackParamList>;

const { width } = Dimensions.get('window');

const SLIDES = [
  {
    key: '1',
    title: Strings.onboarding.slide1.title,
    subtitle: Strings.onboarding.slide1.subtitle,
    icon: 'rocket' as const,
    colors: [Colors.gradient.start, '#9B59B6'] as [string, string],
  },
  {
    key: '2',
    title: Strings.onboarding.slide2.title,
    subtitle: Strings.onboarding.slide2.subtitle,
    icon: 'star' as const,
    colors: ['#9B59B6', Colors.gradient.end] as [string, string],
  },
  {
    key: '3',
    title: Strings.onboarding.slide3.title,
    subtitle: Strings.onboarding.slide3.subtitle,
    icon: 'map' as const,
    colors: [Colors.gradient.end, Colors.gradient.start] as [string, string],
  },
];

const OnboardingScreen: React.FC = () => {
  const navigation = useNavigation<Nav>();
  const [activeIndex, setActiveIndex] = useState(0);
  const listRef = useRef<FlatList>(null);

  const handleDone = async () => {
    await AsyncStorage.setItem(ONBOARDING_KEY, 'true');
    navigation.replace('Auth');
  };

  const handleNext = () => {
    if (activeIndex < SLIDES.length - 1) {
      listRef.current?.scrollToIndex({ index: activeIndex + 1 });
    } else {
      handleDone();
    }
  };

  const onViewableItemsChanged = useRef(
    ({ viewableItems }: { viewableItems: ViewToken[] }) => {
      if (viewableItems.length > 0) setActiveIndex(viewableItems[0].index ?? 0);
    }
  );

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <FlatList
        ref={listRef}
        data={SLIDES}
        keyExtractor={(item) => item.key}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onViewableItemsChanged={onViewableItemsChanged.current}
        viewabilityConfig={{ viewAreaCoveragePercentThreshold: 50 }}
        renderItem={({ item }) => (
          <LinearGradient colors={item.colors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.slide}>
            <View style={styles.iconBox}>
              <Ionicons name={item.icon} size={64} color="rgba(255,255,255,0.9)" />
            </View>
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.subtitle}>{item.subtitle}</Text>
          </LinearGradient>
        )}
      />

      {/* Controls */}
      <View style={styles.controls}>
        <View style={styles.dots}>
          {SLIDES.map((_, i) => (
            <View key={i} style={[styles.dot, i === activeIndex && styles.dotActive]} />
          ))}
        </View>

        <View style={styles.buttons}>
          <TouchableOpacity onPress={handleDone} style={styles.skipBtn}>
            <Text style={styles.skipText}>{Strings.onboarding.skip}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleNext} style={styles.nextBtn} activeOpacity={0.85}>
            <LinearGradient colors={[Colors.gradient.start, Colors.gradient.end]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.nextGradient}>
              <Text style={styles.nextText}>
                {activeIndex === SLIDES.length - 1 ? Strings.onboarding.start : Strings.onboarding.next}
              </Text>
              <Ionicons name={activeIndex === SLIDES.length - 1 ? 'checkmark' : 'arrow-back'} size={18} color="#fff" />
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background.app },
  slide: { width, flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 40 },
  iconBox: {
    width: 140, height: 140, borderRadius: 70,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 40, borderWidth: 2, borderColor: 'rgba(255,255,255,0.3)',
  },
  title: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize['2xl'], color: '#fff', textAlign: 'center', marginBottom: 16 },
  subtitle: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: 'rgba(255,255,255,0.85)', textAlign: 'center', lineHeight: 24 },
  controls: { backgroundColor: Colors.background.card, paddingHorizontal: 24, paddingVertical: 24, paddingBottom: 40 },
  dots: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginBottom: 24 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.ui.border },
  dotActive: { width: 24, backgroundColor: Colors.primary.purple },
  buttons: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  skipBtn: { paddingHorizontal: 20, paddingVertical: 12 },
  skipText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.base, color: Colors.text.secondary },
  nextBtn: { borderRadius: 14, overflow: 'hidden' },
  nextGradient: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 28, paddingVertical: 14 },
  nextText: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.base, color: '#fff' },
});

export default OnboardingScreen;
