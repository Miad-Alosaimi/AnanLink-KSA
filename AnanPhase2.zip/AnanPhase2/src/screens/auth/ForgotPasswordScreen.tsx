import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { Button, Input } from '../../components/common';

const ForgotPasswordScreen: React.FC = () => {
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const handleSend = async () => {
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) {
      setError(Strings.auth.errors.emailInvalid);
      return;
    }
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 1200));
    setIsLoading(false);
    setSent(true);
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <StatusBar style="light" />
      <LinearGradient colors={[Colors.gradient.start, Colors.gradient.end]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.header, { paddingTop: insets.top + 16 }]}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color="#fff" />
        </TouchableOpacity>
        <View style={styles.iconBox}>
          <Ionicons name="lock-open-outline" size={40} color="#fff" />
        </View>
        <Text style={styles.headerTitle}>{Strings.auth.forgotPassword.title}</Text>
        <Text style={styles.headerSub}>{Strings.auth.forgotPassword.subtitle}</Text>
      </LinearGradient>

      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {sent ? (
          <View style={styles.successBox}>
            <View style={styles.successIcon}>
              <Ionicons name="checkmark-circle" size={48} color={Colors.status.success} />
            </View>
            <Text style={styles.successTitle}>{Strings.auth.forgotPassword.successTitle}</Text>
            <Text style={styles.successMsg}>{Strings.auth.forgotPassword.successMessage}</Text>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backLink}>
              <Text style={styles.backLinkText}>{Strings.auth.forgotPassword.backToLogin}</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            <Input
              label={Strings.auth.forgotPassword.emailLabel}
              value={email}
              onChangeText={(v) => { setEmail(v); setError(''); }}
              placeholder={Strings.auth.forgotPassword.emailPlaceholder}
              keyboardType="email-address"
              autoCapitalize="none"
              leftIcon="mail-outline"
              error={error}
            />
            <Button title={Strings.auth.forgotPassword.sendButton} onPress={handleSend} isLoading={isLoading} variant="gradient" style={styles.btn} />
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backLink}>
              <Ionicons name="arrow-back" size={14} color={Colors.primary.purple} />
              <Text style={styles.backLinkText}>{Strings.auth.forgotPassword.backToLogin}</Text>
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background.app },
  header: { paddingHorizontal: 24, paddingBottom: 36, alignItems: 'center' },
  backBtn: { alignSelf: 'flex-end', padding: 4, marginBottom: 16 },
  iconBox: { width: 80, height: 80, borderRadius: 40, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  headerTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize['2xl'], color: '#fff', marginBottom: 8 },
  headerSub: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: 'rgba(255,255,255,0.85)', textAlign: 'center' },
  content: { flexGrow: 1, backgroundColor: Colors.background.card, borderTopLeftRadius: 28, borderTopRightRadius: 28, marginTop: -20, padding: 24, paddingTop: 32 },
  btn: { marginTop: 4, marginBottom: 16 },
  backLink: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  backLinkText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.base, color: Colors.primary.purple },
  successBox: { alignItems: 'center', paddingTop: 20 },
  successIcon: { marginBottom: 16 },
  successTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.xl, color: Colors.text.primary, marginBottom: 10 },
  successMsg: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.secondary, textAlign: 'center', marginBottom: 32, lineHeight: 24 },
});

export default ForgotPasswordScreen;
