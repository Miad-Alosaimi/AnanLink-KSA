import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { AuthStackParamList } from '../../types';
import { Button, Input } from '../../components/common';
import { useAuth } from '../../context';

type Nav = NativeStackNavigationProp<AuthStackParamList>;
type Route = RouteProp<AuthStackParamList, 'RegisterStep2'>;

const SKILLS = Strings.auth.skills;
const SPECIALTIES = Strings.auth.specialties;

const RegisterStep2Screen: React.FC = () => {
  const navigation = useNavigation<Nav>();
  const route = useRoute<Route>();
  const insets = useSafeAreaInsets();
  const { register } = useAuth();
  const { step1Data } = route.params;

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showSpecialtyPicker, setShowSpecialtyPicker] = useState(false);

  const toggleSkill = (skill: string) =>
    setSelectedSkills((prev) => prev.includes(skill) ? prev.filter((s) => s !== skill) : [...prev, skill]);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!password) e.password = Strings.auth.errors.passwordRequired;
    else if (password.length < 8) e.password = Strings.auth.errors.passwordMin;
    if (password !== confirmPassword) e.confirmPassword = Strings.auth.errors.passwordMismatch;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleCreate = async () => {
    if (!validate()) return;
    setIsLoading(true);
    const result = await register({
      ...step1Data,
      specialty: specialty || 'Full Stack',
      password,
      skills: selectedSkills,
    });
    setIsLoading(false);
    if (!result.success) setErrors({ general: result.error ?? '' });
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <LinearGradient
          colors={[Colors.gradient.start, Colors.gradient.end]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={[styles.header, { paddingTop: insets.top + 16 }]}
        >
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={22} color="#fff" />
          </TouchableOpacity>
          <View style={styles.headerContent}>
            <Text style={styles.headerTitle}>{Strings.auth.register.title}</Text>
            <Text style={styles.stepLabel}>{Strings.auth.register.step2Title}</Text>
          </View>
          <View style={styles.stepRow}>
            <View style={styles.stepDot} /><View style={[styles.stepLine, styles.stepLineActive]} /><View style={[styles.stepDot, styles.stepDotActive]} />
          </View>
        </LinearGradient>

        <View style={styles.card}>
          {errors.general ? (
            <View style={styles.errorBanner}>
              <Text style={styles.errorText}>{errors.general}</Text>
            </View>
          ) : null}

          {/* Specialty picker */}
          <View style={styles.fieldWrap}>
            <Text style={styles.label}>{Strings.auth.register.specialtyLabel}</Text>
            <TouchableOpacity style={styles.picker} onPress={() => setShowSpecialtyPicker(!showSpecialtyPicker)}>
              <Text style={specialty ? styles.pickerVal : styles.pickerPlaceholder}>{specialty || 'اختر مسارك التقني'}</Text>
              <Ionicons name={showSpecialtyPicker ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.text.secondary} />
            </TouchableOpacity>
            {showSpecialtyPicker && (
              <View style={styles.dropdown}>
                {SPECIALTIES.map((s) => (
                  <TouchableOpacity key={s} style={styles.dropItem} onPress={() => { setSpecialty(s); setShowSpecialtyPicker(false); }}>
                    <Text style={[styles.dropText, specialty === s && styles.dropSelected]}>{s}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          <Input label={Strings.auth.register.passwordLabel} value={password} onChangeText={setPassword}
            placeholder={Strings.auth.register.passwordPlaceholder} secureTextEntry leftIcon="lock-closed-outline" error={errors.password} />

          <Input label={Strings.auth.register.confirmPasswordLabel} value={confirmPassword} onChangeText={setConfirmPassword}
            placeholder={Strings.auth.register.confirmPasswordPlaceholder} secureTextEntry leftIcon="checkmark-circle-outline" error={errors.confirmPassword} />

          {/* Skills */}
          <View style={styles.fieldWrap}>
            <Text style={styles.label}>{Strings.auth.register.skillsLabel}</Text>
            <View style={styles.skillsGrid}>
              {SKILLS.map((skill) => {
                const active = selectedSkills.includes(skill);
                return (
                  <TouchableOpacity key={skill} onPress={() => toggleSkill(skill)}
                    style={[styles.skillChip, active && styles.skillChipActive]}>
                    <Text style={[styles.skillText, active && styles.skillTextActive]}>{skill}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          <Button title={Strings.auth.register.createButton} onPress={handleCreate} isLoading={isLoading} variant="gradient" />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background.app },
  scroll: { flexGrow: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 28, minHeight: 150, justifyContent: 'flex-end' },
  backBtn: { position: 'absolute', top: 56, right: 20 },
  headerContent: { marginBottom: 16 },
  headerTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize['2xl'], color: '#fff', textAlign: 'right' },
  stepLabel: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.sm, color: 'rgba(255,255,255,0.8)', textAlign: 'right' },
  stepRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 4 },
  stepDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: 'rgba(255,255,255,0.4)', borderWidth: 2, borderColor: 'rgba(255,255,255,0.6)' },
  stepDotActive: { backgroundColor: '#fff' },
  stepLine: { width: 40, height: 2, backgroundColor: 'rgba(255,255,255,0.4)' },
  stepLineActive: { backgroundColor: '#fff' },
  card: { flex: 1, backgroundColor: Colors.background.card, borderTopLeftRadius: 28, borderTopRightRadius: 28, marginTop: -16, paddingHorizontal: 24, paddingTop: 28, paddingBottom: 40 },
  errorBanner: { backgroundColor: '#FEF2F2', borderRadius: 10, padding: 12, marginBottom: 16, borderWidth: 1, borderColor: '#FCA5A5' },
  errorText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.sm, color: Colors.status.error, textAlign: 'right' },
  fieldWrap: { marginBottom: 16 },
  label: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm, color: Colors.text.primary, textAlign: 'right', marginBottom: 8 },
  picker: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: Colors.ui.inputBg, borderRadius: 12, borderWidth: 1.5, borderColor: Colors.ui.border, paddingHorizontal: 14, paddingVertical: 14 },
  pickerVal: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.primary },
  pickerPlaceholder: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.ui.placeholder },
  dropdown: { backgroundColor: Colors.background.card, borderRadius: 12, borderWidth: 1, borderColor: Colors.ui.border, marginTop: 4, overflow: 'hidden', maxHeight: 200 },
  dropItem: { paddingHorizontal: 14, paddingVertical: 11, borderBottomWidth: 1, borderBottomColor: Colors.ui.divider },
  dropText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.primary, textAlign: 'right' },
  dropSelected: { color: Colors.primary.purple, fontFamily: Typography.fontFamily.semiBold },
  skillsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  skillChip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5, borderColor: Colors.ui.border, backgroundColor: Colors.background.card },
  skillChipActive: { backgroundColor: Colors.primary.purple, borderColor: Colors.primary.purple },
  skillText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm, color: Colors.text.secondary },
  skillTextActive: { color: '#fff' },
});

export default RegisterStep2Screen;
