import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { AuthStackParamList } from '../../types';
import { Button, Input } from '../../components/common';

type Nav = NativeStackNavigationProp<AuthStackParamList>;

const UNIVERSITIES = Strings.auth.universities;

const RegisterStep1Screen: React.FC = () => {
  const navigation = useNavigation<Nav>();
  const insets = useSafeAreaInsets();

  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', university: '', major: '', academicYear: 1 });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showUniPicker, setShowUniPicker] = useState(false);

  const set = (key: string, value: string | number) => setForm(f => ({ ...f, [key]: value }));

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.firstName.trim()) e.firstName = Strings.auth.errors.firstNameRequired;
    if (!form.lastName.trim()) e.lastName = Strings.auth.errors.lastNameRequired;
    if (!form.email.trim()) e.email = Strings.auth.errors.emailRequired;
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = Strings.auth.errors.emailInvalid;
    if (!form.university) e.university = Strings.auth.errors.universityRequired;
    if (!form.major.trim()) e.major = Strings.auth.errors.majorRequired;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleNext = () => {
    if (!validate()) return;
    navigation.navigate('RegisterStep2', { step1Data: form });
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <LinearGradient
          colors={[Colors.gradient.start, Colors.gradient.end]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={[styles.header, { paddingTop: insets.top + 16 }]}
        >
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={22} color="#fff" />
          </TouchableOpacity>
          <View style={styles.headerContent}>
            <Text style={styles.headerTitle}>{Strings.auth.register.title}</Text>
            <Text style={styles.stepLabel}>{Strings.auth.register.step1Title}</Text>
          </View>
          {/* Step indicator */}
          <View style={styles.stepRow}>
            <View style={[styles.stepDot, styles.stepDotActive]} /><View style={styles.stepLine} /><View style={styles.stepDot} />
          </View>
        </LinearGradient>

        <View style={styles.card}>
          <View style={styles.nameRow}>
            <View style={{ flex: 1 }}>
              <Input label={Strings.auth.register.firstNameLabel} value={form.firstName}
                onChangeText={(v) => set('firstName', v)} placeholder={Strings.auth.register.firstNameLabel} error={errors.firstName} />
            </View>
            <View style={{ flex: 1 }}>
              <Input label={Strings.auth.register.lastNameLabel} value={form.lastName}
                onChangeText={(v) => set('lastName', v)} placeholder={Strings.auth.register.lastNameLabel} error={errors.lastName} />
            </View>
          </View>

          <Input label={Strings.auth.register.emailLabel} value={form.email}
            onChangeText={(v) => set('email', v)} placeholder={Strings.auth.register.emailPlaceholder}
            keyboardType="email-address" autoCapitalize="none" leftIcon="mail-outline" error={errors.email} />

          {/* University picker */}
          <View style={styles.fieldWrap}>
            <Text style={styles.label}>{Strings.auth.register.universityLabel}</Text>
            <TouchableOpacity style={[styles.picker, errors.university ? styles.pickerError : null]} onPress={() => setShowUniPicker(!showUniPicker)}>
              <Text style={form.university ? styles.pickerVal : styles.pickerPlaceholder}>{form.university || 'اختر جامعتك'}</Text>
              <Ionicons name={showUniPicker ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.text.secondary} />
            </TouchableOpacity>
            {errors.university ? <Text style={styles.errText}>{errors.university}</Text> : null}
            {showUniPicker && (
              <View style={styles.dropdown}>
                {UNIVERSITIES.map((uni) => (
                  <TouchableOpacity key={uni} style={styles.dropItem} onPress={() => { set('university', uni); setShowUniPicker(false); }}>
                    <Text style={[styles.dropText, form.university === uni && styles.dropSelected]}>{uni}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          <Input label={Strings.auth.register.majorLabel} value={form.major}
            onChangeText={(v) => set('major', v)} placeholder={Strings.auth.register.majorPlaceholder}
            leftIcon="book-outline" error={errors.major} />

          <Button title={`${Strings.auth.register.nextButton} ← الخطوة 2`} onPress={handleNext} variant="gradient" />

          <View style={styles.loginRow}>
            <Text style={styles.loginText}>{Strings.auth.register.alreadyHaveAccount}</Text>
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <Text style={styles.loginLink}>{Strings.auth.register.login}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background.app },
  scroll: { flexGrow: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 28, minHeight: 150, justifyContent: 'flex-end' },
  backBtn: { position: 'absolute', top: 56, right: 20 },
  headerContent: { marginBottom: 16 },
  headerTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize['2xl'], color: '#fff', textAlign: 'right' },
  stepLabel: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.sm, color: 'rgba(255,255,255,0.8)', textAlign: 'right' },
  stepRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 4 },
  stepDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: 'rgba(255,255,255,0.4)', borderWidth: 2, borderColor: 'rgba(255,255,255,0.6)' },
  stepDotActive: { backgroundColor: '#fff' },
  stepLine: { width: 40, height: 2, backgroundColor: 'rgba(255,255,255,0.4)' },
  card: { flex: 1, backgroundColor: Colors.background.card, borderTopLeftRadius: 28, borderTopRightRadius: 28, marginTop: -16, paddingHorizontal: 24, paddingTop: 28, paddingBottom: 40 },
  nameRow: { flexDirection: 'row', gap: 12 },
  fieldWrap: { marginBottom: 16 },
  label: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm, color: Colors.text.primary, textAlign: 'right', marginBottom: 6 },
  picker: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: Colors.ui.inputBg, borderRadius: 12, borderWidth: 1.5, borderColor: Colors.ui.border, paddingHorizontal: 14, paddingVertical: 14 },
  pickerError: { borderColor: Colors.status.error },
  pickerVal: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.primary },
  pickerPlaceholder: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.ui.placeholder },
  errText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.status.error, textAlign: 'right', marginTop: 4 },
  dropdown: { backgroundColor: Colors.background.card, borderRadius: 12, borderWidth: 1, borderColor: Colors.ui.border, marginTop: 4, overflow: 'hidden' },
  dropItem: { paddingHorizontal: 14, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: Colors.ui.divider },
  dropText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.primary, textAlign: 'right' },
  dropSelected: { color: Colors.primary.purple, fontFamily: Typography.fontFamily.semiBold },
  loginRow: { flexDirection: 'row', justifyContent: 'center', gap: 6, marginTop: 20 },
  loginText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.secondary },
  loginLink: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.base, color: Colors.primary.purple },
});

export default RegisterStep1Screen;
