import React, { useState, useMemo } from 'react';
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity,
  TextInput, ScrollView, RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { Opportunity, OpportunityType, OpportunitiesStackParamList } from '../../types';
import { useOpportunities } from '../../hooks/useOpportunities';
import { useBookmarks } from '../../context';
import { FilterChip } from '../../components/opportunity';

type Nav = NativeStackNavigationProp<OpportunitiesStackParamList>;
type Route = RouteProp<OpportunitiesStackParamList, 'OpportunityList'>;

const TYPE_COLORS: Record<string, string> = {
  hackathon: Colors.opportunity.hackathon,
  internship: Colors.opportunity.internship,
  opensource: Colors.opportunity.opensource,
  volunteer: Colors.opportunity.volunteer,
};

const FILTERS = [
  { key: 'all', label: Strings.opportunities.filters.all },
  { key: 'hackathon', label: Strings.opportunities.filters.hackathon },
  { key: 'internship', label: Strings.opportunities.filters.internship },
  { key: 'opensource', label: Strings.opportunities.filters.opensource },
  { key: 'volunteer', label: Strings.opportunities.filters.volunteer },
];

const OpportunityListScreen: React.FC = () => {
  const navigation = useNavigation<Nav>();
  const route = useRoute<Route>();
  const insets = useSafeAreaInsets();
  const { opportunities, isLoading, isRefreshing, refresh } = useOpportunities();
  const { isBookmarkedItem, toggleBookmarkItem } = useBookmarks();

  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState<string>(route.params?.type ?? 'all');

  const filtered = useMemo(() => {
    return opportunities.filter((opp) => {
      const matchType = activeFilter === 'all' || opp.type === activeFilter;
      const matchSearch = !search.trim() ||
        opp.title.toLowerCase().includes(search.toLowerCase()) ||
        opp.organization.toLowerCase().includes(search.toLowerCase());
      return matchType && matchSearch;
    });
  }, [opportunities, activeFilter, search]);

  const renderItem = ({ item }: { item: Opportunity }) => {
    const color = TYPE_COLORS[item.type];
    const bookmarked = isBookmarkedItem(item.id);
    return (
      <TouchableOpacity
        style={styles.card}
        activeOpacity={0.85}
        onPress={() => navigation.navigate('OpportunityDetail', { opportunityId: item.id, type: item.type })}
      >
        <View style={styles.cardTop}>
          <TouchableOpacity onPress={() => toggleBookmarkItem(item.id)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Ionicons name={bookmarked ? 'bookmark' : 'bookmark-outline'} size={20} color={bookmarked ? Colors.primary.purple : Colors.text.secondary} />
          </TouchableOpacity>
          <View style={[styles.typeTag, { backgroundColor: color + '20' }]}>
            <Text style={[styles.typeTagText, { color }]}>{(Strings.opportunities.types as any)[item.type]}</Text>
          </View>
        </View>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.org}>{item.organization}</Text>
        <Text style={styles.desc} numberOfLines={2}>{item.description}</Text>
        <View style={styles.cardFooter}>
          <View style={styles.xpTag}>
            <Ionicons name="star" size={12} color={Colors.xp.gold} />
            <Text style={styles.xpText}>{item.xpReward} XP</Text>
          </View>
          {item.deadline ? (
            <View style={styles.deadlineRow}>
              <Ionicons name="calendar-outline" size={12} color={Colors.text.secondary} />
              <Text style={styles.deadlineText}>{item.deadline}</Text>
            </View>
          ) : null}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <LinearGradient
        colors={[Colors.gradient.start, Colors.gradient.end]}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
        style={[styles.header, { paddingTop: insets.top + 16 }]}
      >
        <Text style={styles.headerTitle}>{Strings.opportunities.title}</Text>
        <View style={styles.searchRow}>
          <TextInput
            style={styles.searchInput}
            placeholder={Strings.opportunities.searchPlaceholder}
            placeholderTextColor="rgba(255,255,255,0.6)"
            value={search}
            onChangeText={setSearch}
            textAlign="right"
          />
          <Ionicons name="search" size={20} color="rgba(255,255,255,0.8)" />
        </View>
      </LinearGradient>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.filtersScroll}
        contentContainerStyle={styles.filtersContent}
      >
        {FILTERS.map((f) => (
          <FilterChip
            key={f.key}
            label={f.label}
            active={activeFilter === f.key}
            onPress={() => setActiveFilter(f.key)}
            color={f.key !== 'all' ? TYPE_COLORS[f.key] : Colors.primary.purple}
          />
        ))}
      </ScrollView>

      <FlatList
        data={filtered}
        keyExtractor={(item, idx) => `${item.id}-${idx}`}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={refresh} tintColor={Colors.primary.purple} />}
        ListEmptyComponent={
          !isLoading ? (
            <View style={styles.empty}>
              <Ionicons name="search-outline" size={48} color={Colors.ui.disabled} />
              <Text style={styles.emptyTitle}>{Strings.opportunities.empty.title}</Text>
              <Text style={styles.emptyMsg}>{Strings.opportunities.empty.message}</Text>
            </View>
          ) : null
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background.app },
  header: { paddingHorizontal: 20, paddingBottom: 20 },
  headerTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.xl, color: '#fff', textAlign: 'right', marginBottom: 14 },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10 },
  searchInput: { flex: 1, fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: '#fff' },
  filtersScroll: { maxHeight: 52, backgroundColor: Colors.background.card, borderBottomWidth: 1, borderBottomColor: Colors.ui.divider },
  filtersContent: { paddingHorizontal: 16, paddingVertical: 10, alignItems: 'center' },
  list: { padding: 16, paddingBottom: 32 },
  card: { backgroundColor: Colors.background.card, borderRadius: 16, padding: 16, marginBottom: 14, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  typeTag: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  typeTagText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.xs },
  title: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.base, color: Colors.text.primary, textAlign: 'right', marginBottom: 4 },
  org: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm, color: Colors.primary.purple, textAlign: 'right', marginBottom: 8 },
  desc: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.sm, color: Colors.text.secondary, textAlign: 'right', lineHeight: 20, marginBottom: 12 },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  xpTag: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  xpText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.xs, color: Colors.xp.gold },
  deadlineRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  deadlineText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary },
  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyTitle: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.lg, color: Colors.text.primary },
  emptyMsg: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.secondary, textAlign: 'center' },
});

export default OpportunityListScreen;
