import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Linking, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { Opportunity, OpportunitiesStackParamList } from '../../types';
import { getOpportunityById } from '../../database/db';
import { useBookmarks } from '../../context';
import { Button } from '../../components/common';

type Route = RouteProp<OpportunitiesStackParamList, 'OpportunityDetail'>;

const TYPE_COLORS: Record<string, string> = {
  hackathon: Colors.opportunity.hackathon,
  internship: Colors.opportunity.internship,
  opensource: Colors.opportunity.opensource,
  volunteer: Colors.opportunity.volunteer,
};

const TYPE_LABELS: Record<string, string> = {
  hackathon: Strings.opportunities.types.hackathon,
  internship: Strings.opportunities.types.internship,
  opensource: Strings.opportunities.types.opensource,
  volunteer: Strings.opportunities.types.volunteer,
};

const OpportunityDetailScreen: React.FC = () => {
  const navigation = useNavigation();
  const route = useRoute<Route>();
  const insets = useSafeAreaInsets();
  const { opportunityId } = route.params;
  const { isBookmarkedItem, toggleBookmarkItem } = useBookmarks();

  const [opportunity, setOpportunity] = useState<Opportunity | null>(null);

  useEffect(() => { getOpportunityById(opportunityId).then(setOpportunity); }, [opportunityId]);

  if (!opportunity) return null;

  const color = TYPE_COLORS[opportunity.type];
  const bookmarked = isBookmarkedItem(opportunity.id);

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <LinearGradient
        colors={[color, color + 'AA']}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 12 }]}
      >
        <View style={styles.headerRow}>
          <TouchableOpacity onPress={() => toggleBookmarkItem(opportunity.id)} style={styles.bookmarkBtn}>
            <Ionicons name={bookmarked ? 'bookmark' : 'bookmark-outline'} size={22} color="#fff" />
          </TouchableOpacity>
          <View style={styles.typeChip}>
            <Text style={styles.typeChipText}>{TYPE_LABELS[opportunity.type]}</Text>
          </View>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={22} color="#fff" />
          </TouchableOpacity>
        </View>
        <Text style={styles.headerTitle}>{opportunity.title}</Text>
        <Text style={styles.headerOrg}>{opportunity.organization}</Text>
      </LinearGradient>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Meta */}
        <View style={styles.metaRow}>
          {opportunity.deadline ? (
            <View style={styles.metaItem}>
              <Ionicons name="calendar-outline" size={16} color={color} />
              <View>
                <Text style={styles.metaLabel}>{Strings.opportunities.details.deadline}</Text>
                <Text style={styles.metaValue}>{opportunity.deadline}</Text>
              </View>
            </View>
          ) : null}
          <View style={styles.metaItem}>
            <Ionicons name="location-outline" size={16} color={color} />
            <View>
              <Text style={styles.metaLabel}>{Strings.opportunities.details.location}</Text>
              <Text style={styles.metaValue}>{opportunity.location}</Text>
            </View>
          </View>
          <View style={styles.metaItem}>
            <Ionicons name="star" size={16} color={Colors.xp.gold} />
            <View>
              <Text style={styles.metaLabel}>{Strings.opportunities.details.xpReward}</Text>
              <Text style={[styles.metaValue, { color: Colors.xp.gold }]}>{opportunity.xpReward} XP</Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{Strings.opportunities.details.about}</Text>
          <Text style={styles.description}>{opportunity.description}</Text>
        </View>

        {/* Bookmark banner */}
        <TouchableOpacity
          style={[styles.bookmarkBanner, bookmarked && styles.bookmarkBannerActive]}
          onPress={() => toggleBookmarkItem(opportunity.id)}
          activeOpacity={0.85}
        >
          <Ionicons name={bookmarked ? 'bookmark' : 'bookmark-outline'} size={18} color={bookmarked ? Colors.primary.purple : Colors.text.secondary} />
          <Text style={[styles.bookmarkBannerText, bookmarked && styles.bookmarkBannerTextActive]}>
            {bookmarked ? Strings.opportunities.details.removeBookmark : Strings.opportunities.details.bookmark}
          </Text>
        </TouchableOpacity>

        <View style={styles.registerSection}>
          <Button
            title={Strings.opportunities.details.register}
            variant="gradient"
            onPress={() => {
              if (opportunity.registrationLink) {
                Linking.openURL(opportunity.registrationLink).catch(() => Alert.alert('خطأ', 'تعذّر فتح الرابط'));
              }
            }}
          />
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background.app },
  header: { paddingHorizontal: 20, paddingBottom: 24 },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  bookmarkBtn: { padding: 4 },
  typeChip: { backgroundColor: 'rgba(255,255,255,0.25)', paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20 },
  typeChipText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm, color: '#fff' },
  headerTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize['2xl'], color: '#fff', textAlign: 'right', marginBottom: 6 },
  headerOrg: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.base, color: 'rgba(255,255,255,0.85)', textAlign: 'right' },
  scroll: { flex: 1 },
  metaRow: { flexDirection: 'row', gap: 16, paddingHorizontal: 20, paddingVertical: 20, borderBottomWidth: 1, borderBottomColor: Colors.ui.divider, flexWrap: 'wrap' },
  metaItem: { flexDirection: 'row', gap: 8, alignItems: 'flex-start' },
  metaLabel: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary, textAlign: 'right' },
  metaValue: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.sm, color: Colors.text.primary, textAlign: 'right' },
  section: { padding: 20 },
  sectionTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.lg, color: Colors.text.primary, textAlign: 'right', marginBottom: 10 },
  description: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.secondary, textAlign: 'right', lineHeight: 26 },
  bookmarkBanner: { flexDirection: 'row', alignItems: 'center', gap: 10, justifyContent: 'center', marginHorizontal: 20, paddingVertical: 14, borderRadius: 14, borderWidth: 1.5, borderColor: Colors.ui.border, backgroundColor: Colors.background.card, marginBottom: 12 },
  bookmarkBannerActive: { borderColor: Colors.primary.purple, backgroundColor: Colors.opportunity.hackathonLight },
  bookmarkBannerText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.base, color: Colors.text.secondary },
  bookmarkBannerTextActive: { color: Colors.primary.purple },
  registerSection: { paddingHorizontal: 20, paddingBottom: 40 },
});

export default OpportunityDetailScreen;
