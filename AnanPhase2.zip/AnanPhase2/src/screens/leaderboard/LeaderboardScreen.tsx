import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { getLeaderboard } from '../../database/db';
import { useAuth } from '../../context';

type Period = 'weekly' | 'monthly' | 'alltime';

const PERIOD_FILTERS: { key: Period; label: string }[] = [
  { key: 'weekly', label: Strings.leaderboard.weekly },
  { key: 'monthly', label: Strings.leaderboard.monthly },
  { key: 'alltime', label: Strings.leaderboard.alltime },
];

const MEDALS = ['🥇', '🥈', '🥉'];
const PODIUM_COLORS = [Colors.leaderboard.goldBg, Colors.leaderboard.silverBg, Colors.leaderboard.bronzeBg];
const MEDAL_COLORS = [Colors.leaderboard.gold, Colors.leaderboard.silver, Colors.leaderboard.bronze];

const LeaderboardScreen: React.FC = () => {
  const insets = useSafeAreaInsets();
  const { userId } = useAuth();
  const [users, setUsers] = useState<any[]>([]);
  const [activePeriod, setActivePeriod] = useState<Period>('alltime');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    getLeaderboard(20).then((data) => { setUsers(data); setIsLoading(false); });
  }, []);

  const top3 = users.slice(0, 3);
  const rest = users.slice(3);

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <LinearGradient
        colors={[Colors.gradient.start, Colors.gradient.end]}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
        style={[styles.header, { paddingTop: insets.top + 16 }]}
      >
        <Text style={styles.headerTitle}>{Strings.leaderboard.title}</Text>

        {/* Period tabs */}
        <View style={styles.periodRow}>
          {PERIOD_FILTERS.map((p) => (
            <TouchableOpacity
              key={p.key}
              style={[styles.periodTab, activePeriod === p.key && styles.periodTabActive]}
              onPress={() => setActivePeriod(p.key)}
            >
              <Text style={[styles.periodText, activePeriod === p.key && styles.periodTextActive]}>
                {p.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </LinearGradient>

      {isLoading ? (
        <ActivityIndicator style={{ flex: 1 }} size="large" color={Colors.primary.purple} />
      ) : (
        <FlatList
          data={rest}
          keyExtractor={(item) => String(item.id)}
          ListHeaderComponent={
            <>
              {/* Podium */}
              <View style={styles.podium}>
                {/* 2nd */}
                {top3[1] && (
                  <View style={styles.podiumItem}>
                    <Text style={styles.medal}>{MEDALS[1]}</Text>
                    <View style={[styles.podiumAvatar, { backgroundColor: PODIUM_COLORS[1] }]}>
                      <Text style={styles.podiumInitial}>{top3[1].firstName?.[0] ?? '?'}</Text>
                    </View>
                    <Text style={styles.podiumName} numberOfLines={1}>{top3[1].firstName}</Text>
                    <Text style={[styles.podiumXp, { color: MEDAL_COLORS[1] }]}>{top3[1].xp} {Strings.leaderboard.points}</Text>
                    <View style={[styles.podiumBase, { height: 60, backgroundColor: PODIUM_COLORS[1] }]}>
                      <Text style={styles.podiumRank}>2</Text>
                    </View>
                  </View>
                )}
                {/* 1st */}
                {top3[0] && (
                  <View style={[styles.podiumItem, styles.podiumFirst]}>
                    <Text style={[styles.medal, { fontSize: 28 }]}>{MEDALS[0]}</Text>
                    <View style={[styles.podiumAvatar, styles.podiumAvatarFirst, { backgroundColor: PODIUM_COLORS[0] }]}>
                      <Text style={[styles.podiumInitial, { fontSize: 20 }]}>{top3[0].firstName?.[0] ?? '?'}</Text>
                    </View>
                    <Text style={[styles.podiumName, { fontFamily: Typography.fontFamily.bold }]} numberOfLines={1}>{top3[0].firstName}</Text>
                    <Text style={[styles.podiumXp, { color: MEDAL_COLORS[0], fontSize: Typography.fontSize.sm }]}>{top3[0].xp} {Strings.leaderboard.points}</Text>
                    <View style={[styles.podiumBase, { height: 80, backgroundColor: PODIUM_COLORS[0] }]}>
                      <Text style={styles.podiumRank}>1</Text>
                    </View>
                  </View>
                )}
                {/* 3rd */}
                {top3[2] && (
                  <View style={styles.podiumItem}>
                    <Text style={styles.medal}>{MEDALS[2]}</Text>
                    <View style={[styles.podiumAvatar, { backgroundColor: PODIUM_COLORS[2] }]}>
                      <Text style={styles.podiumInitial}>{top3[2].firstName?.[0] ?? '?'}</Text>
                    </View>
                    <Text style={styles.podiumName} numberOfLines={1}>{top3[2].firstName}</Text>
                    <Text style={[styles.podiumXp, { color: MEDAL_COLORS[2] }]}>{top3[2].xp} {Strings.leaderboard.points}</Text>
                    <View style={[styles.podiumBase, { height: 44, backgroundColor: PODIUM_COLORS[2] }]}>
                      <Text style={styles.podiumRank}>3</Text>
                    </View>
                  </View>
                )}
              </View>
            </>
          }
          renderItem={({ item, index }) => {
            const rank = index + 4;
            const isMe = item.id === userId;
            return (
              <View style={[styles.rankRow, isMe && styles.rankRowMe]}>
                <View style={styles.rankXpBox}>
                  <Text style={styles.rankXp}>{item.xp}</Text>
                  <Text style={styles.rankXpLabel}>{Strings.leaderboard.points}</Text>
                </View>
                <View style={styles.rankInfo}>
                  <Text style={styles.rankName}>{item.fullName}</Text>
                  <Text style={styles.rankUni}>{item.university}</Text>
                </View>
                <View style={[styles.rankNum, isMe && styles.rankNumMe]}>
                  <Text style={[styles.rankNumText, isMe && styles.rankNumTextMe]}>#{rank}</Text>
                </View>
              </View>
            );
          }}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background.app },
  header: { paddingHorizontal: 20, paddingBottom: 20 },
  headerTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.xl, color: '#fff', textAlign: 'center', marginBottom: 16 },
  periodRow: { flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 12, padding: 4, gap: 4 },
  periodTab: { flex: 1, paddingVertical: 8, borderRadius: 9, alignItems: 'center' },
  periodTabActive: { backgroundColor: '#fff' },
  periodText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm, color: 'rgba(255,255,255,0.8)' },
  periodTextActive: { color: Colors.primary.purple },
  list: { paddingBottom: 32 },
  podium: { flexDirection: 'row', justifyContent: 'center', alignItems: 'flex-end', paddingHorizontal: 20, paddingVertical: 24, gap: 12, backgroundColor: Colors.background.card, marginBottom: 8 },
  podiumItem: { alignItems: 'center', flex: 1 },
  podiumFirst: { marginTop: -20 },
  medal: { fontSize: 22, marginBottom: 4 },
  podiumAvatar: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  podiumAvatarFirst: { width: 64, height: 64, borderRadius: 32 },
  podiumInitial: { fontFamily: Typography.fontFamily.bold, fontSize: 16, color: Colors.text.primary },
  podiumName: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.xs, color: Colors.text.primary, textAlign: 'center', marginBottom: 2 },
  podiumXp: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.xs, marginBottom: 8 },
  podiumBase: { width: '100%', borderTopLeftRadius: 8, borderTopRightRadius: 8, alignItems: 'center', justifyContent: 'center' },
  podiumRank: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.xl, color: Colors.text.secondary },
  rankRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 14, backgroundColor: Colors.background.card, borderBottomWidth: 1, borderBottomColor: Colors.ui.divider },
  rankRowMe: { backgroundColor: Colors.opportunity.hackathonLight },
  rankNum: { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.ui.divider, alignItems: 'center', justifyContent: 'center' },
  rankNumMe: { backgroundColor: Colors.primary.purple },
  rankNumText: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.sm, color: Colors.text.secondary },
  rankNumTextMe: { color: '#fff' },
  rankInfo: { flex: 1, paddingHorizontal: 12 },
  rankName: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.base, color: Colors.text.primary, textAlign: 'right' },
  rankUni: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary, textAlign: 'right' },
  rankXpBox: { alignItems: 'center' },
  rankXp: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.base, color: Colors.primary.purple },
  rankXpLabel: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary },
});

export default LeaderboardScreen;
