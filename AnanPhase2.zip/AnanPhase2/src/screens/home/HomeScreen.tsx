import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  FlatList, RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { HomeStackParamList, Opportunity, OpportunityType } from '../../types';
import { useUser } from '../../context';
import { getRecentOpportunities, getOpportunityCountByType } from '../../database/db';

type Nav = NativeStackNavigationProp<HomeStackParamList>;

const CATEGORIES = [
  { type: 'hackathon' as OpportunityType, label: Strings.home.categories.hackathon, icon: 'rocket', color: Colors.opportunity.hackathon },
  { type: 'internship' as OpportunityType, label: Strings.home.categories.internship, icon: 'briefcase', color: Colors.opportunity.internship },
  { type: 'opensource' as OpportunityType, label: Strings.home.categories.opensource, icon: 'code-slash', color: Colors.opportunity.opensource },
  { type: 'volunteer' as OpportunityType, label: Strings.home.categories.volunteer, icon: 'heart', color: Colors.opportunity.volunteer },
];

const HomeScreen: React.FC = () => {
  const navigation = useNavigation<Nav>();
  const insets = useSafeAreaInsets();
  const { user } = useUser();

  const [recentOpps, setRecentOpps] = useState<Opportunity[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({ hackathon: 0, internship: 0, opensource: 0, volunteer: 0 });
  const [isRefreshing, setIsRefreshing] = useState(false);

  const loadData = async () => {
    const [recent, countMap] = await Promise.all([getRecentOpportunities(5), getOpportunityCountByType()]);
    setRecentOpps(recent);
    setCounts(countMap);
  };

  useEffect(() => { loadData(); }, []);

  const onRefresh = async () => { setIsRefreshing(true); await loadData(); setIsRefreshing(false); };

  const levelProgress = user ? (user.xp % 100) / 100 : 0;
  const xpToNext = ((user?.level ?? 1) * 100) - (user?.xp ?? 0);

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={onRefresh} tintColor={Colors.primary.purple} />}
      >
        <LinearGradient
          colors={[Colors.gradient.start, Colors.gradient.end]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={[styles.header, { paddingTop: insets.top + 16 }]}
        >
          <View style={styles.decorCircle} />
          <View style={styles.headerRow}>
            <TouchableOpacity onPress={() => navigation.navigate('HomeMap')}>
              <Ionicons name="map-outline" size={24} color="#fff" />
            </TouchableOpacity>
            <View style={styles.headerCenter}>
              <Text style={styles.greeting}>{Strings.home.greeting} {user?.firstName ?? ''}</Text>
              <Text style={styles.subGreeting}>اكتشف الفرص المتاحة</Text>
            </View>
            <View style={styles.levelBadge}>
              <Text style={styles.levelBadgeText}>⭐ {Strings.home.level} {user?.level ?? 1}</Text>
            </View>
          </View>

          {/* XP Card */}
          <View style={styles.xpCard}>
            <View style={styles.xpRow}>
              <View style={styles.xpCircle}>
                <Text style={styles.xpNum}>{user?.level ?? 1}</Text>
                <Text style={styles.xpLbl}>{Strings.home.level}</Text>
              </View>
              <View style={styles.xpBar}>
                <Text style={styles.xpBarLabel}>{user?.xp ?? 0} / {(user?.level ?? 1) * 100} XP</Text>
                <View style={styles.xpTrack}>
                  <LinearGradient
                    colors={[Colors.gradient.start, Colors.gradient.end]}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                    style={[styles.xpFill, { width: `${Math.min(levelProgress * 100, 100)}%` }]}
                  />
                </View>
                <Text style={styles.xpSub}>{xpToNext > 0 ? `${xpToNext} ${Strings.home.xpProgress}` : 'وصلت للمستوى الأعلى!'}</Text>
              </View>
            </View>
            <View style={styles.statsRow}>
              {[
                { label: Strings.home.stats.applications, value: '0' },
                { label: Strings.home.stats.hackathons, value: '0' },
                { label: Strings.home.stats.points, value: String(user?.xp ?? 0) },
              ].map((s, i) => (
                <View key={i} style={styles.statItem}>
                  <Text style={styles.statVal}>{s.value}</Text>
                  <Text style={styles.statLbl}>{s.label}</Text>
                </View>
              ))}
            </View>
          </View>
        </LinearGradient>

        <View style={styles.content}>
          {/* Category Grid */}
          <View style={styles.grid}>
            {CATEGORIES.map((cat) => (
              <TouchableOpacity key={cat.type} style={styles.catCard} activeOpacity={0.85}
                onPress={() => navigation.getParent()?.navigate('OpportunitiesTab', { type: cat.type })}>
                <LinearGradient colors={[cat.color + 'DD', cat.color]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.catGradient}>
                  <Ionicons name={cat.icon as any} size={26} color="#fff" />
                  <Text style={styles.catLabel}>{cat.label}</Text>
                  <Text style={styles.catCount}>{counts[cat.type]} {Strings.home.available}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>

          {/* Recent Opportunities */}
          <View style={styles.sectionHeader}>
            <TouchableOpacity onPress={() => navigation.getParent()?.navigate('OpportunitiesTab', {})}>
              <Text style={styles.viewAll}>{Strings.home.viewAll}</Text>
            </TouchableOpacity>
            <Text style={styles.sectionTitle}>{Strings.home.recentOpportunities}</Text>
          </View>

          <FlatList
            data={recentOpps}
            horizontal
            showsHorizontalScrollIndicator={false}
            keyExtractor={(opp) => String(opp.id)}
            contentContainerStyle={styles.hList}
            renderItem={({ item: opp }) => {
              const color = (Colors.opportunity as any)[opp.type];
              return (
                <TouchableOpacity
                  style={styles.miniCard}
                  onPress={() => navigation.navigate('OpportunityDetail', { opportunityId: opp.id, type: opp.type })}
                  activeOpacity={0.85}
                >
                  <View style={[styles.miniTypeTag, { backgroundColor: color + '22' }]}>
                    <Text style={[styles.miniTypeText, { color }]}>{(Strings.home.categories as any)[opp.type]}</Text>
                  </View>
                  <Text style={styles.miniTitle} numberOfLines={2}>{opp.title}</Text>
                  <Text style={styles.miniOrg} numberOfLines={1}>{opp.organization}</Text>
                  <View style={styles.miniXp}>
                    <Ionicons name="star" size={12} color={Colors.xp.gold} />
                    <Text style={styles.miniXpText}>{opp.xpReward} XP</Text>
                  </View>
                </TouchableOpacity>
              );
            }}
          />

          {/* Map CTA */}
          <TouchableOpacity onPress={() => navigation.navigate('HomeMap')} activeOpacity={0.9}>
            <LinearGradient
              colors={[Colors.gradient.end + 'CC', Colors.gradient.start + 'CC']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={styles.mapCard}
            >
              <View>
                <Text style={styles.mapTitle}>{Strings.home.viewMap}</Text>
                <Text style={styles.mapSub}>اعثر على الفرص القريبة منك</Text>
              </View>
              <Ionicons name="map" size={40} color="rgba(255,255,255,0.8)" />
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background.app },
  header: { paddingHorizontal: 20, paddingBottom: 32, overflow: 'hidden' },
  decorCircle: { position: 'absolute', width: 300, height: 300, borderRadius: 150, backgroundColor: 'rgba(255,255,255,0.06)', top: -80, right: -60 },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  headerCenter: { flex: 1, alignItems: 'center' },
  greeting: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.lg, color: '#fff', textAlign: 'center' },
  subGreeting: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.sm, color: 'rgba(255,255,255,0.8)' },
  levelBadge: { backgroundColor: 'rgba(255,255,255,0.2)', paddingVertical: 5, paddingHorizontal: 10, borderRadius: 20 },
  levelBadgeText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.xs, color: '#fff' },
  xpCard: { backgroundColor: 'rgba(255,255,255,0.95)', borderRadius: 20, padding: 16 },
  xpRow: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 12 },
  xpCircle: { width: 56, height: 56, borderRadius: 28, backgroundColor: Colors.opportunity.hackathonLight, alignItems: 'center', justifyContent: 'center' },
  xpNum: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.xl, color: Colors.primary.purple },
  xpLbl: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary },
  xpBar: { flex: 1 },
  xpBarLabel: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.sm, color: Colors.text.primary, textAlign: 'right', marginBottom: 6 },
  xpTrack: { height: 8, backgroundColor: Colors.ui.border, borderRadius: 4, overflow: 'hidden' },
  xpFill: { height: '100%', borderRadius: 4 },
  xpSub: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary, textAlign: 'right', marginTop: 4 },
  statsRow: { flexDirection: 'row', justifyContent: 'space-around', paddingTop: 12, borderTopWidth: 1, borderTopColor: Colors.ui.divider },
  statItem: { alignItems: 'center' },
  statVal: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.lg, color: Colors.primary.purple },
  statLbl: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary },
  content: { paddingHorizontal: 20, paddingTop: 20, paddingBottom: 32 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 24 },
  catCard: { width: '47%', borderRadius: 16, overflow: 'hidden' },
  catGradient: { padding: 16, gap: 6, minHeight: 100 },
  catLabel: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.base, color: '#fff' },
  catCount: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: 'rgba(255,255,255,0.85)' },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  sectionTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.lg, color: Colors.text.primary },
  viewAll: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.sm, color: Colors.primary.purple },
  hList: { paddingBottom: 8, gap: 12 },
  miniCard: { width: 200, backgroundColor: Colors.background.card, borderRadius: 16, padding: 14, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  miniTypeTag: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, alignSelf: 'flex-end', marginBottom: 8 },
  miniTypeText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.xs },
  miniTitle: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.sm, color: Colors.text.primary, textAlign: 'right', marginBottom: 4 },
  miniOrg: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary, textAlign: 'right', marginBottom: 10 },
  miniXp: { flexDirection: 'row', alignItems: 'center', gap: 4, justifyContent: 'flex-end' },
  miniXpText: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.xs, color: Colors.xp.gold },
  mapCard: { borderRadius: 16, padding: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 },
  mapTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.lg, color: '#fff' },
  mapSub: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.sm, color: 'rgba(255,255,255,0.85)' },
});

export default HomeScreen;
