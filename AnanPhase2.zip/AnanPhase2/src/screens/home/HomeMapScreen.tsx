import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, Linking } from 'react-native';
import MapView, { Marker, Callout } from 'react-native-maps';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography } from '../../constants';
import { Opportunity } from '../../types';
import { getOpportunitiesWithLocation } from '../../database/db';

const TYPE_COLORS: Record<string, string> = {
  hackathon: Colors.opportunity.hackathon,
  internship: Colors.opportunity.internship,
  opensource: Colors.opportunity.opensource,
  volunteer: Colors.opportunity.volunteer,
};

const HomeMapScreen: React.FC = () => {
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  useEffect(() => {
    getOpportunitiesWithLocation().then(setOpportunities);
    requestLocation();
  }, []);

  const requestLocation = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status === 'granted') {
      const loc = await Location.getCurrentPositionAsync({});
      setUserLocation({ latitude: loc.coords.latitude, longitude: loc.coords.longitude });
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar style="light" />

      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={22} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>الخريطة التفاعلية</Text>
        <View style={{ width: 36 }} />
      </View>

      <MapView
        style={styles.map}
        initialRegion={{ latitude: 24.7136, longitude: 46.6753, latitudeDelta: 4, longitudeDelta: 4 }}
        showsUserLocation={!!userLocation}
        showsMyLocationButton={false}
      >
        {opportunities.map((opp) =>
          opp.latitude && opp.longitude ? (
            <Marker
              key={opp.id}
              coordinate={{ latitude: opp.latitude, longitude: opp.longitude }}
              pinColor={TYPE_COLORS[opp.type]}
            >
              <Callout>
                <View style={styles.callout}>
                  <Text style={styles.calloutTitle}>{opp.title}</Text>
                  <Text style={styles.calloutOrg}>{opp.organization}</Text>
                </View>
              </Callout>
            </Marker>
          ) : null
        )}
      </MapView>

      {/* Legend */}
      <View style={styles.legend}>
        {Object.entries(TYPE_COLORS).map(([type, color]) => (
          <View key={type} style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: color }]} />
            <Text style={styles.legendText}>{type === 'hackathon' ? 'هاكاثون' : type === 'internship' ? 'تدريب' : type === 'opensource' ? 'مصدر مفتوح' : 'تطوعي'}</Text>
          </View>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background.app },
  header: {
    backgroundColor: Colors.primary.purple, paddingHorizontal: 16, paddingBottom: 16,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
  },
  backBtn: { padding: 4 },
  headerTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.lg, color: '#fff' },
  map: { flex: 1 },
  callout: { width: 180, padding: 8 },
  calloutTitle: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.sm, color: Colors.text.primary, textAlign: 'right', marginBottom: 2 },
  calloutOrg: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary, textAlign: 'right' },
  legend: {
    position: 'absolute', bottom: 20, left: 16, right: 16,
    backgroundColor: 'rgba(255,255,255,0.95)', borderRadius: 16, padding: 14,
    flexDirection: 'row', justifyContent: 'space-around', flexWrap: 'wrap', gap: 8,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4,
  },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendDot: { width: 10, height: 10, borderRadius: 5 },
  legendText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.xs, color: Colors.text.secondary },
});

export default HomeMapScreen;
