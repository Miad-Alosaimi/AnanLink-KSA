import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, Linking } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as Haptics from 'expo-haptics';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { Colors, Typography, Strings } from '../../constants';
import { saveScanLog, updateUserXP } from '../../database/db';
import { useAuth } from '../../context';

const QRScannerScreen: React.FC = () => {
  const insets = useSafeAreaInsets();
  const { userId } = useAuth();
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [scanResult, setScanResult] = useState<{ title: string; xp: number } | null>(null);

  const handleBarCodeScanned = async ({ data }: { data: string }) => {
    if (scanned) return;
    setScanned(true);
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    let eventTitle = 'فعالية غير معروفة';
    let eventType = 'event';
    let xpEarned = 50;
    let eventId = String(Date.now());

    try {
      const parsed = JSON.parse(data);
      eventTitle = parsed.title ?? eventTitle;
      eventType = parsed.type ?? eventType;
      xpEarned = parsed.xp ?? xpEarned;
      eventId = parsed.id ?? eventId;
    } catch {
      eventTitle = data.substring(0, 50);
    }

    if (userId) {
      await saveScanLog({ userId, eventId, eventTitle, eventType, xpEarned, rawQrData: data });
      await updateUserXP(userId, xpEarned);
    }

    setScanResult({ title: eventTitle, xp: xpEarned });
  };

  if (!permission) return <View style={styles.center}><Text style={styles.permText}>جاري التحقق من الصلاحيات...</Text></View>;

  if (!permission.granted) {
    return (
      <View style={[styles.center, { paddingTop: insets.top + 20 }]}>
        <Ionicons name="camera-outline" size={60} color={Colors.primary.purple} style={{ marginBottom: 16 }} />
        <Text style={styles.permTitle}>{Strings.qr.permissionTitle}</Text>
        <Text style={styles.permMsg}>{Strings.qr.permissionMessage}</Text>
        <TouchableOpacity style={styles.permBtn} onPress={requestPermission}>
          <Text style={styles.permBtnText}>{Strings.qr.requestPermission}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (scanResult) {
    return (
      <View style={[styles.successScreen, { paddingTop: insets.top + 20 }]}>
        <StatusBar style="dark" />
        <View style={styles.successIcon}>
          <Ionicons name="checkmark-circle" size={80} color={Colors.status.success} />
        </View>
        <Text style={styles.successTitle}>{Strings.qr.success}</Text>
        <Text style={styles.successEventName}>{scanResult.title}</Text>
        <View style={styles.xpBadge}>
          <Ionicons name="star" size={20} color={Colors.xp.gold} />
          <Text style={styles.xpText}>{Strings.qr.xpEarned} {scanResult.xp} {Strings.qr.xpUnit}</Text>
        </View>
        <TouchableOpacity style={styles.doneBtn} onPress={() => { setScanResult(null); setScanned(false); }}>
          <Text style={styles.doneBtnText}>{Strings.qr.scanAgain}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.scanner}>
      <StatusBar style="light" />
      <CameraView style={styles.camera} facing="back" onBarcodeScanned={handleBarCodeScanned} barcodeScannerSettings={{ barcodeTypes: ['qr'] }}>
        <View style={[styles.overlay, { paddingTop: insets.top + 16 }]}>
          <Text style={styles.scanTitle}>{Strings.qr.title}</Text>
          <View style={styles.scanFrame}>
            <View style={[styles.corner, styles.cornerTL]} />
            <View style={[styles.corner, styles.cornerTR]} />
            <View style={[styles.corner, styles.cornerBL]} />
            <View style={[styles.corner, styles.cornerBR]} />
          </View>
          <Text style={styles.scanInstruction}>{Strings.qr.instruction}</Text>
        </View>
      </CameraView>
    </View>
  );
};

const CORNER_SIZE = 26;
const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32, backgroundColor: Colors.background.app },
  permTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.xl, color: Colors.text.primary, textAlign: 'center', marginBottom: 10 },
  permMsg: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.secondary, textAlign: 'center', marginBottom: 28, lineHeight: 24 },
  permText: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: Colors.text.secondary },
  permBtn: { backgroundColor: Colors.primary.purple, borderRadius: 14, paddingVertical: 15, paddingHorizontal: 40 },
  permBtnText: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.base, color: '#fff' },
  scanner: { flex: 1 },
  camera: { flex: 1 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center', justifyContent: 'space-evenly' },
  scanTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize.xl, color: '#fff' },
  scanFrame: { width: 240, height: 240, position: 'relative' },
  corner: { position: 'absolute', width: CORNER_SIZE, height: CORNER_SIZE, borderColor: '#fff', borderWidth: 3 },
  cornerTL: { top: 0, left: 0, borderRightWidth: 0, borderBottomWidth: 0, borderTopLeftRadius: 6 },
  cornerTR: { top: 0, right: 0, borderLeftWidth: 0, borderBottomWidth: 0, borderTopRightRadius: 6 },
  cornerBL: { bottom: 0, left: 0, borderRightWidth: 0, borderTopWidth: 0, borderBottomLeftRadius: 6 },
  cornerBR: { bottom: 0, right: 0, borderLeftWidth: 0, borderTopWidth: 0, borderBottomRightRadius: 6 },
  scanInstruction: { fontFamily: Typography.fontFamily.regular, fontSize: Typography.fontSize.base, color: 'rgba(255,255,255,0.85)', textAlign: 'center', paddingHorizontal: 40 },
  successScreen: { flex: 1, backgroundColor: Colors.background.app, alignItems: 'center', justifyContent: 'center', padding: 32 },
  successIcon: { marginBottom: 20 },
  successTitle: { fontFamily: Typography.fontFamily.bold, fontSize: Typography.fontSize['2xl'], color: Colors.text.primary, marginBottom: 10 },
  successEventName: { fontFamily: Typography.fontFamily.medium, fontSize: Typography.fontSize.lg, color: Colors.text.secondary, textAlign: 'center', marginBottom: 24 },
  xpBadge: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: Colors.xp.goldLight, borderRadius: 20, paddingHorizontal: 20, paddingVertical: 10, marginBottom: 32 },
  xpText: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.lg, color: Colors.xp.gold },
  doneBtn: { backgroundColor: Colors.primary.purple, borderRadius: 14, paddingVertical: 15, paddingHorizontal: 48 },
  doneBtnText: { fontFamily: Typography.fontFamily.semiBold, fontSize: Typography.fontSize.base, color: '#fff' },
});

export default QRScannerScreen;
