export const Strings = {
  app: { name: 'عنان لينك', tagline: 'وصلتك لكل الفرص التقنية' },
  navigation: { home: 'الرئيسية', opportunities: 'الفرص', profile: 'حسابي' },
  auth: {
    login: {
      title: 'مرحباً بعودتك', subtitle: 'سجّل دخولك للوصول لجميع الفرص',
      emailLabel: 'البريد الجامعي', emailPlaceholder: 'أدخل بريدك الجامعي',
      passwordLabel: 'كلمة المرور', passwordPlaceholder: 'كلمة المرور',
      loginButton: 'تسجيل الدخول', noAccount: 'ليس لديك حساب؟', signUp: 'سجّل الآن',
    },
    register: {
      title: 'إنشاء حساب جديد',
      firstNameLabel: 'الاسم الأول', lastNameLabel: 'اسم العائلة',
      emailLabel: 'البريد الجامعي', emailPlaceholder: 'أدخل بريدك الجامعي',
      universityLabel: 'الجامعة', majorLabel: 'التخصص', majorPlaceholder: 'علوم الحاسب',
      passwordLabel: 'كلمة المرور', passwordPlaceholder: 'كلمة مرور قوية',
      createButton: 'إنشاء الحساب', alreadyHaveAccount: 'لديك حساب؟', login: 'سجّل دخولك',
    },
    errors: {
      emailRequired: 'البريد الجامعي مطلوب', emailInvalid: 'أدخل بريداً صحيحاً',
      passwordRequired: 'كلمة المرور مطلوبة', passwordMin: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل',
      firstNameRequired: 'الاسم الأول مطلوب', lastNameRequired: 'اسم العائلة مطلوب',
      universityRequired: 'الجامعة مطلوبة', majorRequired: 'التخصص مطلوب',
    },
    universities: [
      'جامعة الملك فهد للبترول والمعادن (KFUPM)',
      'جامعة الملك عبدالعزيز (KAU)',
      'جامعة الملك سعود (KSU)',
      'جامعة أم القرى (UQU)',
      'جامعة الأمير سلطان (PSU)',
      'أخرى',
    ],
  },
  home: {
    greeting: 'مرحباً،',
    categories: { hackathon: 'هاكاثون', internship: 'تدريب', opensource: 'مصدر مفتوح', volunteer: 'تطوعي' },
    recentOpportunities: 'آخر الفرص', viewAll: 'عرض الكل', available: 'متاح',
  },
  opportunities: {
    title: 'الفرص المتاحة',
    types: { hackathon: 'هاكاثون', internship: 'تدريب', opensource: 'مصدر مفتوح', volunteer: 'تطوعي' },
    details: { about: 'عن الفرصة', deadline: 'الموعد النهائي', location: 'الموقع', register: 'سجّل الآن' },
    empty: { title: 'لا توجد فرص حالياً', message: 'تحقق لاحقاً' },
  },
  profile: {
    title: 'حسابي', university: 'الجامعة', major: 'التخصص',
    logout: 'تسجيل الخروج', logoutConfirm: 'هل تريد تسجيل الخروج؟',
    logoutYes: 'نعم', logoutNo: 'لا',
  },
};
